package main

import "redteam/internal/server"

func main() {
	server.Start()
}
