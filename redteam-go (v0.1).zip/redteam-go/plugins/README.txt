===========================================
  SecITRed - Plugin System Documentation
===========================================

OVERVIEW:
Plugins allow you to extend SecITRed without modifying the source code.
Each plugin is a simple JSON file that defines how to run external tools.

REQUIREMENTS:
- The external program must be installed on your system or accessible via PATH
- JSON file must be placed in the 'plugins/' folder
- File extension must be .json

---

PLUGIN STRUCTURE (Fields):

{
  "name": "unique-tool-name",
    → Unique identifier (lowercase, no spaces)
    → This appears in the sidebar menu

  "category": "recon",
    → Category for grouping: recon, redteam, blueteam, crypto, misc

  "description": "Brief description of what this tool does.",
    → Shown in the Tool Info tab

  "command": "nmap",
    → The executable to run (must be in PATH or use full path)
    → Examples: "nmap", "python", "bash", "./scripts/myscript.sh"

  "args": ["-F", "{{input}}", "--port", "{{key}}"],
    → Array of command-line arguments
    → Use placeholders:
       {{input}} = Text from the main input field
       {{key}}   = Text from the Key/Parameter field

  "inputLabel": "Target IP Address",
    → Label shown in the UI for the main input field

  "keyLabel": "Port Number",
    → Label for the optional Key field (leave empty if not used)

  "needsKey": false
    → true = Key field is required (highlighted in UI)
    → false = Key field is optional or hidden
}

---

EXAMPLES:

1. NMAP FAST SCAN
File: plugins/nmap-fast.json
{
  "name": "nmap-fast",
  "category": "recon",
  "description": "Fast port scan (top 100 ports) using Nmap.",
  "command": "nmap",
  "args": ["-F", "{{input}}"],
  "inputLabel": "Target IP",
  "needsKey": false
}
Requirements: Nmap must be installed (nmap.org)

---

2. PYTHON SCRIPT WRAPPER
File: plugins/custom-exploit.json
{
  "name": "my-exploit",
  "category": "redteam",
  "description": "Runs a custom Python exploit script.",
  "command": "python3",
  "args": ["plugins/scripts/exploit.py", "-t", "{{input}}", "-p", "{{key}}"],
  "inputLabel": "Target Host",
  "keyLabel": "Target Port",
  "needsKey": true
}
Requirements: Python 3 installed + script at plugins/scripts/exploit.py

---

3. CURL API CALL
File: plugins/shodan-curl.json
{
  "name": "shodan-curl",
  "category": "recon",
  "description": "Queries Shodan API using curl (requires API key).",
  "command": "curl",
  "args": ["-s", "https://api.shodan.io/shodan/host/{{input}}?key={{key}}"],
  "inputLabel": "IP Address",
  "keyLabel": "Shodan API Key",
  "needsKey": true
}
Requirements: curl installed

---

SECURITY NOTES:
- Plugins execute external programs with user-provided input
- Never run untrusted JSON files
- Plugins have a 30-second timeout to prevent hanging processes
- Input is NOT sanitized - be careful with special characters

TROUBLESHOOTING:
Error: "executable file not found in $PATH"
→ The command is not installed or not in your system PATH
→ Use full path: "command": "/usr/bin/nmap" or "C:\\Tools\\nmap.exe"

Plugin not showing in UI?
→ Check JSON syntax (use jsonlint.com)
→ Restart SecITRed after adding/modifying plugins
→ Check logs tab for errors

---

For more examples, visit: github.com/YourName/SecITRed
