package server

import "net/http"

var tokens = map[string]string{
	"admin-token": "admin",
	"user-token":  "operator",
}

func require(role string, h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		t := r.Header.Get("Authorization")
		if tokens[t] != role {
			http.Error(w, "Forbidden", 403)
			return
		}
		h(w, r)
	}
}
