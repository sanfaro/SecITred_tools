package server

import (
	"encoding/json"
	"net/http"

	"redteam/internal/debug"
	"redteam/internal/tools"
)

func registerRoutes(mux *http.ServeMux) {

	// static web
	mux.Handle("/", http.FileServer(http.Dir("./web")))

	// run tool
	mux.HandleFunc("/api/run", func(w http.ResponseWriter, r *http.Request) {
		debug.Log("API /run called")

		var req map[string]string
		json.NewDecoder(r.Body).Decode(&req)

		tool := req["tool"]
		text := req["text"]

		var result string

		switch tool {
		case "echo":
			result = text
		case "caesar":
			result = tools.Caesar(text, 3)
		default:
			result = "UNKNOWN TOOL"
		}

		debug.Log("RESULT: " + result)
		json.NewEncoder(w).Encode(map[string]string{
			"result": result,
		})
	})

	// logs
	mux.HandleFunc("/api/logs", func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(debug.GetLogs())
	})
}
