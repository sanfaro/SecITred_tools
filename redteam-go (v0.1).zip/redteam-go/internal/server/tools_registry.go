package server

// Tool definiuje metadane narzędzia dla Frontendu.
// Frontend używa tego do renderowania listy i dostosowania UI (labele, inputy).
type Tool struct {
	Name        string `json:"name"`
	Category    string `json:"category"`
	NeedsKey    bool   `json:"needsKey"`    // Czy pokazać dodatkowe pole input?
	Description string `json:"description"` // Krótki opis co narzędzie robi (tooltip)
	InputLabel  string `json:"inputLabel"`  // Podpowiedź w głównym polu tekstowym
	KeyLabel    string `json:"keyLabel"`    // Podpowiedź w polu klucza (jeśli NeedsKey=true)
}

// toolRegistry to "Menu" aplikacji.
// Kolejność tutaj decyduje o kolejności na liście w Web UI (można sortować JS-em, ale to baza).
var toolRegistry = []Tool{
	// --- KRYPTOGRAFIA (CRYPTO) ---
	{
		Name:        "base64",
		Category:    "crypto",
		NeedsKey:    false,
		Description: "Encodes or decodes text to/from Base64 format.",
		InputLabel:  "Text to encode",
		KeyLabel:    "",
	},
	{
		Name:        "xor",
		Category:    "crypto",
		NeedsKey:    true,
		Description: "Applies XOR cipher to input using a specific key.",
		InputLabel:  "Raw Bytes / Text",
		KeyLabel:    "XOR Key (String/Hex)",
	},
	{
		Name:        "rot13",
		Category:    "crypto",
		NeedsKey:    false,
		Description: "Replaces each letter with the 13th letter after it.",
		InputLabel:  "Text to rotate",
		KeyLabel:    "",
	},
	{
		Name:        "caesar",
		Category:    "crypto",
		NeedsKey:    true,
		Description: "Caesar cipher shift substitution.",
		InputLabel:  "Text to shift",
		KeyLabel:    "Shift Amount (Integer)",
	},
	{
		Name:        "sha256",
		Category:    "crypto",
		NeedsKey:    false,
		Description: "Generates SHA256 hash digest of the input.",
		InputLabel:  "Text to hash",
		KeyLabel:    "",
	},
	{
		Name:        "hashid",
		Category:    "crypto",
		NeedsKey:    false,
		Description: "Identifies hash type based on length and format.",
		InputLabel:  "Hash string (e.g. 5e8848...)",
		KeyLabel:    "",
	},

	// --- RECONNAISSANCE (RECON) ---
	{
		Name:        "subdomains",
		Category:    "recon",
		NeedsKey:    false,
		Description: "Finds subdomains using crt.sh (Passive Recon).",
		InputLabel:  "Domain (e.g. google.com)",
		KeyLabel:    "",
	},
	{
		Name:        "portscan",
		Category:    "recon",
		NeedsKey:    false,
		Description: "Scans top 20 common TCP ports on target.",
		InputLabel:  "Target IP or Hostname",
		KeyLabel:    "",
	},
	{
		Name:        "dns",
		Category:    "recon",
		NeedsKey:    false,
		Description: "Fetches DNS records (A, MX, TXT, NS, SOA).",
		InputLabel:  "Domain name",
		KeyLabel:    "",
	},
	{
		Name:        "shodan",
		Category:    "recon",
		NeedsKey:    false, // false, bo klucz jest zazwyczaj w ENV, ale można dać true dla override
		Description: "Queries Shodan API for host information.",
		InputLabel:  "IP Address",
		KeyLabel:    "API Key (Optional override)",
	},
	{
		Name:        "virustotal",
		Category:    "recon",
		NeedsKey:    false,
		Description: "Checks IP reputation on VirusTotal.",
		InputLabel:  "IP Address",
		KeyLabel:    "API Key (Optional override)",
	},
	{
		Name:        "abuseipdb",
		Category:    "recon",
		NeedsKey:    false,
		Description: "Checks IP against AbuseIPDB database.",
		InputLabel:  "IP Address",
		KeyLabel:    "API Key (Optional override)",
	},

	// --- RED TEAM / OFFENSIVE ---
	{
		Name:        "revshell",
		Category:    "redteam",
		NeedsKey:    true,
		Description: "Generates Reverse Shell one-liners (Bash, Python, etc.).",
		InputLabel:  "Attacker IP (LHOST)",
		KeyLabel:    "Listening Port (LPORT)",
	},

	// --- BLUE TEAM / DEFENSIVE ---
	{
		Name:        "httpheaders",
		Category:    "blueteam",
		NeedsKey:    false,
		Description: "Analyzes HTTP security headers (HSTS, CSP, etc.).",
		InputLabel:  "Target URL (https://...)",
		KeyLabel:    "",
	},
	{
		Name:        "whois",
		Category:    "blueteam",
		NeedsKey:    false,
		Description: "Performs WHOIS lookup for domain registration info.",
		InputLabel:  "Domain name",
		KeyLabel:    "",
	},
	{
		Name:        "emailheaders",
		Category:    "blueteam",
		NeedsKey:    false,
		Description: "Analyzes email headers for phishing indicators (SPF, DKIM, DMARC).",
		InputLabel:  "Raw Email Headers (paste full headers)",
		KeyLabel:    "",
	},


	// --- MISC / WEB UTILS ---
	{
		Name:        "jwt",
		Category:    "misc",
		NeedsKey:    false,
		Description: "Decodes JWT token header and payload (no verify).",
		InputLabel:  "JWT Token (eyJ...)",
		KeyLabel:    "",
	},
	{
		Name:        "mac",
		Category:    "misc",
		NeedsKey:    false,
		Description: "Looks up device manufacturer by MAC Address.",
		InputLabel:  "MAC Address (AA:BB:CC...)",
		KeyLabel:    "",
	},
	{
		Name:        "urlencode",
		Category:    "misc",
		NeedsKey:    false,
		Description: "URL Encodes special characters.",
		InputLabel:  "Text to encode",
		KeyLabel:    "",
	},
	{
		Name:        "echo",
		Category:    "misc",
		NeedsKey:    false,
		Description: "Returns the input text (Connectivity test).",
		InputLabel:  "Any text",
		KeyLabel:    "",
	},
}
