package debug

import (
	"sync"
	"time"
)

var (
	logs []string
	mu   sync.Mutex
)

func Log(msg string) {
	mu.Lock()
	defer mu.Unlock()
	logs = append(logs, time.Now().Format("15:04:05")+" "+msg)
	if len(logs) > 200 {
		logs = logs[len(logs)-200:]
	}
}

func GetLogs() []string {
	mu.Lock()
	defer mu.Unlock()
	return logs
}
