package tools

import (
	"io"
	"net/http"
)

func OTX(input, apiKey string) string {
	req, _ := http.NewRequest(
		"GET",
		"https://otx.alienvault.com/api/v1/indicators/IPv4/"+input+"/general",
		nil,
	)

	if apiKey != "" {
		req.Header.Set("X-OTX-API-KEY", apiKey)
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err.Error()
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	return string(body)
}
