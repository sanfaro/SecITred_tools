package tools

import (
	"fmt"
	"regexp"
)

func HashIdentifier(hash string) string {
	hash = regexp.MustCompile(`\s+`).ReplaceAllString(hash, "") // usuń białe znaki
	l := len(hash)

	// Sprawdzenie czy to w ogóle hex
	isHex, _ := regexp.MatchString("^[a-fA-F0-9]+$", hash)
	if !isHex {
		// Może to bcrypt?
		if len(hash) == 60 && hash[:4] == "$2a$" {
			return "Identified: Bcrypt (Blowfish)"
		}
		if len(hash) == 34 && hash[:3] == "$P$" {
			return "Identified: WordPress (MD5)"
		}
		return "Unknown format (not standard hex)"
	}

	var candidates []string

	switch l {
	case 32:
		candidates = []string{"MD5", "MD4", "NTLM"}
	case 40:
		candidates = []string{"SHA-1", "RIPEMD-160", "MySQL5"}
	case 56:
		candidates = []string{"SHA-224"}
	case 64:
		candidates = []string{"SHA-256", "GOST", "Haval-256"}
	case 96:
		candidates = []string{"SHA-384"}
	case 128:
		candidates = []string{"SHA-512", "Whirlpool"}
	}

	if len(candidates) > 0 {
		return fmt.Sprintf("Possible Hash Types (Length %d):\n- %s", l, fmt.Sprintf("%v", candidates))
	}

	return fmt.Sprintf("Unknown Hash Length: %d characters", l)
}
