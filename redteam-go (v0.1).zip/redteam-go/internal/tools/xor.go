package tools

func XOR(text, key string) string {
	if key == "" {
		return "KEY REQUIRED"
	}

	out := []byte{}
	k := []byte(key)

	for i := range []byte(text) {
		out = append(out, text[i]^k[i%len(k)])
	}
	return string(out)
}
