package tools

import "net/url"

func URLEncode(text string) string {
	return url.QueryEscape(text)
}
