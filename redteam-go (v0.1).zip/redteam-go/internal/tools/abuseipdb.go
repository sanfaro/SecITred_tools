package tools

import (
	"io"
	"net/http"
)

func AbuseIPDB(input, apiKey string) string {
	if apiKey == "" {
		return "ERROR: AbuseIPDB API key required"
	}

	req, _ := http.NewRequest(
		"GET",
		"https://api.abuseipdb.com/api/v2/check?ipAddress="+input+"&maxAgeInDays=90",
		nil,
	)

	req.Header.Set("Key", apiKey)
	req.Header.Set("Accept", "application/json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err.Error()
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	return string(body)
}
