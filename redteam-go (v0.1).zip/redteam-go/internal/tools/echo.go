package tools

func Echo(input string) string {
	return input
}
