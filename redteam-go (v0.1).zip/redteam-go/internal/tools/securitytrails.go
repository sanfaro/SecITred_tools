package tools

import (
	"io"
	"net/http"
)

func SecurityTrails(input, apiKey string) string {
	if apiKey == "" {
		return "ERROR: SecurityTrails API key required"
	}

	req, _ := http.NewRequest(
		"GET",
		"https://api.securitytrails.com/v1/domain/"+input,
		nil,
	)

	req.Header.Set("APIKEY", apiKey)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err.Error()
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	return string(body)
}
