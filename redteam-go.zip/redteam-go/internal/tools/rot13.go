package tools

func ROT13(text string) string {
	return Caesar(text, 13)
}
