package tools

import (
	"bytes"
	"io"
	"net/http"
)

func URLScan(input, apiKey string) string {
	if apiKey == "" {
		return "ERROR: URLScan API key required"
	}

	jsonBody := []byte(`{"url":"` + input + `"}`)

	req, _ := http.NewRequest(
		"POST",
		"https://urlscan.io/api/v1/scan/",
		bytes.NewBuffer(jsonBody),
	)

	req.Header.Set("API-Key", apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err.Error()
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	return string(body)
}
