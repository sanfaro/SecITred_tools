package tools

func Caesar(text string, shift int) string {
	out := []rune{}
	for _, c := range text {
		switch {
		case c >= 'a' && c <= 'z':
			out = append(out, 'a'+(c-'a'+rune(shift))%26)
		case c >= 'A' && c <= 'Z':
			out = append(out, 'A'+(c-'A'+rune(shift))%26)
		default:
			out = append(out, c)
		}
	}
	return string(out)
}
