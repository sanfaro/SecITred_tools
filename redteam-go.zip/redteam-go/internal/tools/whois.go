package tools

import "fmt"

func Whois(target string) string {
	return fmt.Sprintf("WHOIS lookup helper for: %s\n(use external service)", target)
}
