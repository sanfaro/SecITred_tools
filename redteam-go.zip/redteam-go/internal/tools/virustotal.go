package tools

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
)

func VirusTotal(input, apiKey string) string {
	if apiKey == "" {
		return "ERROR: VirusTotal API key required"
	}

	url := fmt.Sprintf("https://www.virustotal.com/api/v3/ip_addresses/%s", input)

	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("x-apikey", apiKey)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err.Error()
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	var parsed map[string]interface{}
	json.Unmarshal(body, &parsed)

	return string(body)
}
