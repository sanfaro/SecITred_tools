package tools

import (
	"io"
	"net/http"
)

func Shodan(input, apiKey string) string {
	if apiKey == "" {
		return "ERROR: Shodan API key required"
	}

	url := "https://api.shodan.io/shodan/host/" + input + "?key=" + apiKey

	resp, err := http.Get(url)
	if err != nil {
		return err.Error()
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	return string(body)
}
