package server

type Tool struct {
	Name     string `json:"name"`
	Category string `json:"category"`
	NeedsKey bool   `json:"needsKey"`
}

var toolRegistry = []Tool{
	{"echo", "misc", false},
	{"caesar", "crypto", false},
	{"rot13", "crypto", false},
	{"base64", "crypto", false},
	{"sha256", "crypto", false},
	{"xor", "crypto", true},
	{"urlencode", "web", false},
	{"whois", "web", false},
}
