package server

import (
	"net/http"
	"os"
)

func handlePlugins(w http.ResponseWriter, r *http.Request) {
	data, err := os.ReadFile("plugins/nmap.json")
	if err != nil {
		http.Error(w, "plugin not found", 404)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(data)
}
