package server

import (
	"os"
	"path/filepath"
	"strings"
	"embed"
	"encoding/json"
	"net/http"
	"sync"
	"time"
	"io/fs"
	"log"
	"strconv"

	"redteam/internal/tools"
)



//go:embed web/*
var webFS embed.FS

type Request struct {
	Tool string `json:"tool"`
	Text string `json:"text"`
	Key  string `json:"key"`
}

type HistoryEntry struct {
	Time   string `json:"time"`
	Tool   string `json:"tool"`
	Input  string `json:"input"`
	Output string `json:"output"`
}

type ToolResponse struct {
	Result      string `json:"result"`
	ExternalURL string `json:"external_url,omitempty"`
}


type ToolInfo struct {
	Name     string `json:"name"`
	Category string `json:"category"`
	NeedsKey bool   `json:"needsKey"`
}

var (
	history []HistoryEntry
	mu      sync.Mutex
)

func Start() {
	log.Println("Starting server...")

	mux := http.NewServeMux()

	// embed frontend
	sub, err := fs.Sub(webFS, "web")
	if err != nil {
		log.Fatal("FS SUB ERROR:", err)
	}

	mux.Handle("/", http.FileServer(http.FS(sub)))

	// endpointy
	mux.HandleFunc("/api/tools", handleTools)
	mux.HandleFunc("/api/run", handleRun)

	// stuby dla pozostałych endpointów (można potem implementować)
	// mux.HandleFunc("/api/profiles", handleProfiles)
	// mux.HandleFunc("/api/projects", handleProjects)
	// mux.HandleFunc("/api/projects/select", handleSelectProject)
	// mux.HandleFunc("/api/report", handleReport)
	// mux.HandleFunc("/api/plugins", handlePlugins)

	log.Println("Listening on :8080")
	log.Fatal(http.ListenAndServe(":8080", mux))
}

// ------------------ HANDLERY ------------------

func handleRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}

	var req Request
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request", 400)
		return
	}

	var out string
	var link string

	// konwersja key do int jeśli Caesar
	var shift int
	if req.Key != "" {
		shift, _ = strconv.Atoi(req.Key)
	}

	switch req.Tool {
	
	case "otx":
	out = tools.OTX(req.Text, req.Key)
	link = "https://otx.alienvault.com/indicator/ip/" + req.Text

	case "greynoise":
		out = tools.GreyNoise(req.Text, req.Key)
		link = "https://viz.greynoise.io/ip/" + req.Text

	case "securitytrails":
		out = tools.SecurityTrails(req.Text, req.Key)
		link = "https://securitytrails.com/domain/" + req.Text
	
	case "virustotal":
	out = tools.VirusTotal(req.Text, req.Key)
	link = "https://www.virustotal.com/gui/ip-address/" + req.Text

	case "abuseipdb":
		out = tools.AbuseIPDB(req.Text, req.Key)
		link = "https://www.abuseipdb.com/check/" + req.Text

	case "shodan":
		out = tools.Shodan(req.Text, req.Key)
		link = "https://www.shodan.io/host/" + req.Text

	case "urlscan":
		out = tools.URLScan(req.Text, req.Key)
	case "base64":
		out = tools.Base64Encode(req.Text)
	case "sha256":
		out = tools.SHA256(req.Text)
	case "xor":
		out = tools.XOR(req.Text, req.Key)
	case "whois":
		out = tools.Whois(req.Text)
	case "echo":
		out = tools.Echo(req.Text)
	case "caesar":
		out = tools.Caesar(req.Text, shift)
	case "rot13":
		out = tools.ROT13(req.Text)
	case "urlencode":
		out = tools.URLEncode(req.Text)
	default:
		out = "UNKNOWN TOOL"
	}

	// zapis historii
	entry := HistoryEntry{
		Time:   time.Now().Format(time.RFC3339),
		Tool:   req.Tool,
		Input:  req.Text,
		Output: out,
	}

	mu.Lock()
	history = append(history, entry)
	mu.Unlock()

resp := ToolResponse{
	Result: out,
}

if link != "" {
	resp.ExternalURL = link
}

w.Header().Set("Content-Type", "application/json")
json.NewEncoder(w).Encode(resp)

}


func handleTools(w http.ResponseWriter, r *http.Request) {
	var toolsList []ToolInfo

	err := filepath.Walk("internal/tools", func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() || !strings.HasSuffix(info.Name(), ".go") {
			return nil
		}

		name := strings.TrimSuffix(info.Name(), ".go")

		category := "misc"
		if strings.Contains(name, "caesar") ||
			strings.Contains(name, "rot") ||
			strings.Contains(name, "xor") ||
			strings.Contains(name, "sha") ||
			strings.Contains(name, "base64") {
			category = "crypto"
		}
		if strings.Contains(name, "url") ||
			strings.Contains(name, "whois") {
			category = "web"
		}

		needsKey := name == "xor"

		toolsList = append(toolsList, ToolInfo{
			Name:     name,
			Category: category,
			NeedsKey: needsKey,
		})
		return nil
	})

	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(toolsList)
}
