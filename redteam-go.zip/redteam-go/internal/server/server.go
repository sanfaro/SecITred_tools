package server

import (
	"os"
	"path/filepath"
	"strings"
	"embed"
	"encoding/json"
	"net/http"
	"sync"
	"time"
	"redteam/internal/tools"
)

//go:embed web/*
var webFS embed.FS

type Request struct {
	Tool string `json:"tool"`
	Text string `json:"text"`
	Key  string `json:"key"`
}

type HistoryEntry struct {
	Time   string `json:"time"`
	Tool   string `json:"tool"`
	Input  string `json:"input"`
	Output string `json:"output"`
}
type ToolInfo struct {
	Name     string `json:"name"`
	Category string `json:"category"`
	NeedsKey bool   `json:"needsKey"`
}


var (
	history []HistoryEntry
	mu      sync.Mutex
)

func Start() {
	mux := http.NewServeMux()

	mux.Handle("/", http.FileServer(http.FS(webFS)))
	mux.HandleFunc("/api/tools", handleTools)
	mux.HandleFunc("/api/run", handleRun)
	mux.HandleFunc("/api/profiles", handleProfiles)
	mux.HandleFunc("/api/projects", handleProjects)
	mux.HandleFunc("/api/projects/select", handleSelectProject)
	mux.HandleFunc("/api/report", handleReport)
	mux.HandleFunc("/api/plugins", handlePlugins)

	http.ListenAndServe(":8080", mux)
}

func handleRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}
	
func handleTools(w http.ResponseWriter, r *http.Request) {
	var tools []ToolInfo

	err := filepath.Walk("internal/tools", func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if info.IsDir() {
			return nil
		}
		if !strings.HasSuffix(info.Name(), ".go") {
			return nil
		}

		name := strings.TrimSuffix(info.Name(), ".go")

		category := "misc"
		if strings.Contains(name, "caesar") ||
			strings.Contains(name, "rot") ||
			strings.Contains(name, "xor") ||
			strings.Contains(name, "sha") ||
			strings.Contains(name, "base64") {
			category = "crypto"
		}
		if strings.Contains(name, "url") ||
			strings.Contains(name, "whois") {
			category = "web"
		}

		needsKey := name == "xor"

		tools = append(tools, ToolInfo{
			Name:     name,
			Category: category,
			NeedsKey: needsKey,
		})
		return nil
	})

	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(tools)
}


	var req Request
	json.NewDecoder(r.Body).Decode(&req)

	var out string
	switch req.Tool {
	case "base64":
		out = tools.Base64Encode(req.Text)
	case "sha256":
		out = tools.SHA256(req.Text)
	case "xor":
		out = tools.XOR(req.Text, req.Key)
	case "whois":
		out = tools.Whois(req.Text)
	default:
		out = "UNKNOWN TOOL"
	}

	entry := HistoryEntry{
		Time:   time.Now().Format(time.RFC3339),
		Tool:   req.Tool,
		Input:  req.Text,
		Output: out,
	}

	mu.Lock()
	history = append(history, entry)
	mu.Unlock()

	w.Write([]byte(out))
}
