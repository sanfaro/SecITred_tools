package server

import (
	"embed"
	"encoding/json"
	"io/fs"
	"log"
	"net/http"
	"sync"
	"time"

	"redteam/internal/tools"
)

//go:embed web/*
var webFS embed.FS

// ===== DATA =====
var (
	debugLogs []string
	history   []HistoryEntry
	apiKeys   = make(map[string]string)
	mutex     sync.Mutex
)

// ===== STRUCTS =====
type Request struct {
	Tool string `json:"tool"`
	Text string `json:"text"`
	Key  string `json:"key"`
}

type ToolInfo struct {
	Name     string `json:"name"`
	Category string `json:"category"`
	NeedsKey bool   `json:"needsKey"`
}

type HistoryEntry struct {
	Time   string `json:"time"`
	Tool   string `json:"tool"`
	Input  string `json:"input"`
	Output string `json:"output"`
}

// ===== TOOLS REGISTRY =====
var availableTools = []ToolInfo{
	{"echo", "misc", false},
	{"caesar", "crypto", false},
	{"base64", "crypto", false},
	{"xor", "crypto", true},
	{"sha256", "crypto", false},
	{"rot13", "crypto", false},
	{"urlencode", "web", false},
	{"whois", "intel", false},
	{"useragent", "web", false},
}

// ===== UTILS =====
func logDebug(msg string) {
	log.Println(msg)
	mutex.Lock()
	defer mutex.Unlock()
	debugLogs = append(debugLogs, msg)
	if len(debugLogs) > 200 {
		debugLogs = debugLogs[len(debugLogs)-200:]
	}
}

// ===== SERVER =====
func Start() {
	mux := http.NewServeMux()

	sub, err := fs.Sub(webFS, "web")
	if err != nil {
		log.Fatal(err)
	}

	mux.Handle("/", http.FileServer(http.FS(sub)))

	mux.HandleFunc("/api/run", handleRun)
	mux.HandleFunc("/api/tools", handleTools)
	mux.HandleFunc("/api/logs", handleLogs)
	mux.HandleFunc("/api/history", handleHistory)
	mux.HandleFunc("/api/export", handleExport)
	mux.HandleFunc("/api/apikey", handleAPIKey)

	logDebug("Server started on :8080")
	log.Fatal(http.ListenAndServe(":8080", mux))
}

// ===== HANDLERS =====
func handleRun(w http.ResponseWriter, r *http.Request) {
	var req Request
	json.NewDecoder(r.Body).Decode(&req)

	var out string

	switch req.Tool {
	case "echo":
		out = req.Text
	case "caesar":
		out = tools.Caesar(req.Text, 3)
	case "base64":
		out = tools.Base64Encode(req.Text)
	case "xor":
		out = tools.XOR(req.Text, req.Key)
	case "sha256":
		out = tools.SHA256(req.Text)
	case "rot13":
		out = tools.ROT13(req.Text)
	case "urlencode":
		out = tools.URLEncode(req.Text)
	case "whois":
		out = tools.Whois(req.Text)
	case "useragent":
		out = tools.RandomUserAgent()
	default:
		out = "UNKNOWN TOOL"
	}

	entry := HistoryEntry{
		Time:   time.Now().Format(time.RFC3339),
		Tool:   req.Tool,
		Input:  req.Text,
		Output: out,
	}

	mutex.Lock()
	history = append(history, entry)
	mutex.Unlock()

	logDebug("[RUN] " + req.Tool)

	w.Write([]byte(out))
}

func handleTools(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(availableTools)
}

func handleLogs(w http.ResponseWriter, r *http.Request) {
	mutex.Lock()
	defer mutex.Unlock()
	json.NewEncoder(w).Encode(debugLogs)
}

func handleHistory(w http.ResponseWriter, r *http.Request) {
	mutex.Lock()
	defer mutex.Unlock()
	json.NewEncoder(w).Encode(history)
}

func handleExport(w http.ResponseWriter, r *http.Request) {
	mutex.Lock()
	defer mutex.Unlock()
	w.Header().Set("Content-Disposition", "attachment; filename=history.json")
	json.NewEncoder(w).Encode(history)
}

func handleAPIKey(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)

	for k, v := range data {
		apiKeys[k] = v
		logDebug("API key set: " + k)
	}

	w.Write([]byte("OK"))
}
