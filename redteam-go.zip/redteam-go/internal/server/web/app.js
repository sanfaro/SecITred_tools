let tools = [];

function tab(id){
  document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

function loadTools(){
  fetch("/api/tools").then(r=>r.json()).then(d=>{
    tools=d;
    tool.innerHTML="";
    d.forEach(t=>{
      let o=document.createElement("option");
      o.value=t.name;
      o.textContent=`${t.category} :: ${t.name}`;
      tool.appendChild(o);
    });
    updateKey();
  });
}

function updateKey(){
  let t=tools.find(x=>x.name===tool.value);
  key.style.display = t && t.needsKey ? "block":"none";
}

function run(){
  fetch("/api/run",{method:"POST",headers:{"Content-Type":"application/json"},
  body:JSON.stringify({tool:tool.value,text:text.value,key:key.value})})
  .then(r=>r.text()).then(o=>output.textContent=o);
}

function loadHistory(){
  fetch("/api/history").then(r=>r.json())
  .then(h=>historyOut.textContent=JSON.stringify(h,null,2));
}

function exportHistory(){
  window.location="/api/export";
}

function loadLogs(){
  fetch("/api/logs").then(r=>r.json())
  .then(l=>logs.textContent=l.join("\n"));
}

tool.addEventListener("change",updateKey);
loadTools();
setInterval(loadLogs,1500);

