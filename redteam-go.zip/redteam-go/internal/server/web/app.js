let tools=[],active=null,toolHistory=[];

function tabMain(name){
  document.querySelectorAll('#workspace > div').forEach(d=>d.classList.add('hidden'));
  document.getElementById('main-'+name).classList.remove('hidden');
  document.querySelectorAll('.nav').forEach(n=>n.classList.remove('active'));
  event.target.classList.add('active');
}

function tabToolkit(name){
  document.querySelectorAll('[id^="tk-"]').forEach(d=>d.classList.add('hidden'));
  document.getElementById('tk-'+name).classList.remove('hidden');
  document.querySelectorAll('.subnav div').forEach(d=>d.classList.remove('active'));
  event.target.classList.add('active');
}

async function loadTools(){
  const r=await fetch('/api/tools'); tools=await r.json();
  const box=toolbox; box.innerHTML='';
  const g={};
  tools.forEach(t=>(g[t.category]=g[t.category]||[]).push(t));
  Object.keys(g).forEach(c=>{
    const d=document.createElement('div'); d.className='category';
    d.innerHTML=`<h4>${c}</h4>`;
    g[c].forEach(t=>{
      const i=document.createElement('div');
      i.className='tool'; i.textContent=t.name;
      i.onclick=()=>selectTool(t,i);
      d.appendChild(i);
    });
    box.appendChild(d);
  });
}

function selectTool(t,el){
  document.querySelectorAll('.tool').forEach(x=>x.classList.remove('active'));
  el.classList.add('active'); active=t;
  toolName.textContent=t.name;
  text.disabled=false; runBtn.disabled=false;
  key.classList.toggle('hidden',!t.needsKey);
}

async function run(){
  if(!active) return;

  status.textContent = 'running';

  const r = await fetch('/api/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      tool: active.name,
      text: text.value,
      key: key.value
    })
  });

  const data = await r.json();   // ⬅⬅⬅ TO JEST KLUCZOWA ZMIANA

  // OUTPUT
  output.textContent = data.result || '';

  // LINK ZEWNĘTRZNY (VT / Shodan / AbuseIPDB)
  if (data.external_url) {
    const br = document.createElement('br');
    const a = document.createElement('a');

    a.href = data.external_url;
    a.target = '_blank';
    a.textContent = 'Open external report';

    output.appendChild(br);
    output.appendChild(a);
  }

  // HISTORIA
  toolHistory.push({
    tool: active.name,
    input: text.value,
    output: data.result,
    external: data.external_url || ''
  });

  history.textContent = JSON.stringify(toolHistory, null, 2);
  status.textContent = 'idle';
}


function runBatch(){
  batchOut.textContent='';
  const list=batch.value.split('\n').filter(Boolean);
  list.forEach(t=>batchOut.textContent+=`Executed: ${t}\n`);
}

function exportData(type){
  const blob=new Blob(
    [type==='json'?JSON.stringify(toolHistory,null,2):toolHistory.map(x=>x.output).join('\n')],
    {type:'text/plain'}
  );
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='export.'+type;
  a.click();
}

async function createProject(){
  await fetch('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name:projName.value})
  });
  ws.textContent=projName.value;
}

async function genReport(){ window.open('/api/report','_blank'); }
async function loadLogs(){
  const r=await fetch('/api/logs');
  logs.textContent=(await r.json()).join("\n");
}

loadTools(); setInterval(loadLogs,1500);

