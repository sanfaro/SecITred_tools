package server

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
)

var currentProject = "default"

func handleProjects(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusMethodNotAllowed)
		return
	}

	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)

	name := data["name"]
	if name == "" {
		http.Error(w, "missing name", 400)
		return
	}

	path := filepath.Join("internal/data/projects", name)
	os.MkdirAll(path, 0755)

	historyFile := filepath.Join(path, "history.json")
	if _, err := os.Stat(historyFile); os.IsNotExist(err) {
		os.WriteFile(historyFile, []byte("[]"), 0644)
	}

	w.Write([]byte("OK"))
}

func handleSelectProject(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusMethodNotAllowed)
		return
	}

	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)

	if data["name"] == "" {
		http.Error(w, "missing name", 400)
		return
	}

	currentProject = data["name"]
	w.Write([]byte("OK"))
}
