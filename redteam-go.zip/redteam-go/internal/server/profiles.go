package server

import (
	"encoding/json"
	"net/http"
)

type Profile struct {
	Name  string   `json:"name"`
	Tools []string `json:"tools"`
}

var profiles = []Profile{
	{"Recon", []string{"whois", "urlencode"}},
	{"Crypto", []string{"base64", "sha256", "xor"}},
	{"Web", []string{"urlencode"}},
}

func handleProfiles(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(profiles)
}
