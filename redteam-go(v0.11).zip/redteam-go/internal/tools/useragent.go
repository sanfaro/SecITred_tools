package tools

import "math/rand"

var agents = []string{
	"Mozilla/5.0",
	"curl/7.88",
	"python-requests/2.x",
	"Go-http-client/1.1",
}

func RandomUserAgent() string {
	return agents[rand.Intn(len(agents))]
}
