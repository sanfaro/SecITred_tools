package tools

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strings"
)

func JWTDecode(token string) string {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return "Error: Invalid JWT format (expected 3 parts separated by dots)."
	}

	decodePart := func(p string, name string) string {
		// Fix padding
		if l := len(p) % 4; l > 0 {
			p += strings.Repeat("=", 4-l)
		}
		data, err := base64.URLEncoding.DecodeString(p)
		if err != nil {
			// Try standard encoding if URL encoding fails
			data, err = base64.StdEncoding.DecodeString(p)
			if err != nil {
				return fmt.Sprintf("[%s] Error decoding: %v", name, err)
			}
		}
		
		var prettyJSON map[string]interface{}
		if err := json.Unmarshal(data, &prettyJSON); err == nil {
			indented, _ := json.MarshalIndent(prettyJSON, "", "  ")
			return string(indented)
		}
		return string(data)
	}

	var sb strings.Builder
	sb.WriteString("=== JWT HEADER ===\n")
	sb.WriteString(decodePart(parts[0], "HEADER"))
	sb.WriteString("\n\n=== JWT PAYLOAD ===\n")
	sb.WriteString(decodePart(parts[1], "PAYLOAD"))
	sb.WriteString("\n\n=== SIGNATURE (Hidden) ===\n")
	sb.WriteString("[Signature bytes present but not verified without secret]")

	return sb.String()
}
