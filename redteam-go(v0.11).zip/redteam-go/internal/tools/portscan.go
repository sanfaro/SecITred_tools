package tools

import (
	"fmt"
	"net"
	"sort"
	"sync"
	"time"
)

func PortScan(target string) string {
	// Top 20 najpopularniejszych portów dla szybkości
	ports := []int{21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1723, 3306, 3389, 5900, 8080, 8443}
	
	results := make(chan int)
	var openPorts []int
	var wg sync.WaitGroup

	// Skanowanie
	for _, port := range ports {
		wg.Add(1)
		go func(p int) {
			defer wg.Done()
			address := fmt.Sprintf("%s:%d", target, p)
			conn, err := net.DialTimeout("tcp", address, 1*time.Second)
			if err == nil {
				conn.Close()
				results <- p
			}
		}(port)
	}

	// Zamykanie kanału po zakończeniu wszystkich goroutines
	go func() {
		wg.Wait()
		close(results)
	}()

	for p := range results {
		openPorts = append(openPorts, p)
	}

	sort.Ints(openPorts)

	if len(openPorts) == 0 {
		return fmt.Sprintf("No open top-20 ports found on %s (or host is down/firewalled).", target)
	}

	return fmt.Sprintf("Open ports on %s:\n%v", target, openPorts)
}
