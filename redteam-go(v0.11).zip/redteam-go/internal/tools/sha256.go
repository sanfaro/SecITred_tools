package tools

import (
	"crypto/sha256"
	"encoding/hex"
)

func SHA256(text string) string {
	h := sha256.Sum256([]byte(text))
	return hex.EncodeToString(h[:])
}
