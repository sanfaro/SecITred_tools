package tools

import (
	"fmt"
	"strings"
)

func UserAgentParser(ua string) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Analyzing UA: %s\n\n", ua))

	// Detekcja OS
	os := "Unknown"
	if strings.Contains(ua, "Windows NT 10.0") {
		os = "Windows 10 / 11"
	}
	if strings.Contains(ua, "Windows NT 6.1") {
		os = "Windows 7"
	}
	if strings.Contains(ua, "Mac OS X") {
		os = "macOS"
	}
	if strings.Contains(ua, "Linux") {
		os = "Linux"
	}
	if strings.Contains(ua, "Android") {
		os = "Android"
	}
	if strings.Contains(ua, "iPhone") {
		os = "iOS"
	}

	// Detekcja Przeglądarki
	browser := "Unknown"
	if strings.Contains(ua, "Firefox/") {
		browser = "Firefox"
	}
	if strings.Contains(ua, "Chrome/") {
		browser = "Chrome (or Chromium based)"
	}
	if strings.Contains(ua, "Safari/") && !strings.Contains(ua, "Chrome") {
		browser = "Safari"
	}
	if strings.Contains(ua, "Edg/") {
		browser = "Edge"
	}
	if strings.Contains(ua, "curl") || strings.Contains(ua, "python") || strings.Contains(ua, "powershell") {
		browser = " SCRIPT / BOT"
	}

	// Znane Boty
	bot := ""
	if strings.Contains(ua, "Googlebot") {
		bot = "Google Bot"
	}
	if strings.Contains(ua, "bingbot") {
		bot = "Bing Bot"
	}
	if strings.Contains(ua, "masscan") || strings.Contains(ua, "nmap") {
		bot = " SCANNER"
	}

	sb.WriteString(fmt.Sprintf("OS:       %s\n", os))
	sb.WriteString(fmt.Sprintf("Browser:  %s\n", browser))
	
	if bot != "" {
		sb.WriteString(fmt.Sprintf("Type:     %s\n", bot))
	}

	// Ocena ryzyka - Poprawiona składnia if/else
	if browser == "SCRIPT / BOT" || bot == " SCANNER" {
		sb.WriteString("\nResult:  SUSPICIOUS (Likely automated tool)")
	} else if len(ua) < 20 {
		sb.WriteString("\nResult:  SUSPICIOUS (Too short)")
	} else {
		sb.WriteString("\nResult:  Normal User-Agent structure")
	}

	return sb.String()
}
