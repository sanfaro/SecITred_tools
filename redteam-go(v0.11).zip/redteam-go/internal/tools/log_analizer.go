package tools

import (
	"fmt"
	"strings"
)

func LogAnalyzer(logs string) string {
	lines := strings.Split(logs, "\n")
	var sb strings.Builder
	
	sb.WriteString(fmt.Sprintf("Scanned %d lines of logs.\n\n", len(lines)))
	sb.WriteString("=== DETECTED THREATS ===\n")

	threatsFound := 0

	// Słownik sygnatur (bardzo uproszczony)
	signatures := map[string]string{
		"UNION SELECT": "SQL Injection",
		"' OR '1'='1": "SQL Injection",
		"alert(": "XSS (Cross-Site Scripting)",
		"<script>": "XSS (Cross-Site Scripting)",
		"/etc/passwd": "LFI (Local File Inclusion)",
		"../../": "Directory Traversal",
		"eval(": "Code Injection / Webshell",
		"base64_decode": "Obfuscated Payload",
		"cmd.exe": "RCE (Remote Code Execution)",
		"/bin/sh": "RCE (Remote Code Execution)",
		"wget ": "Dropper Download",
		"curl ": "Dropper Download",
	}

	for i, line := range lines {
		for sig, desc := range signatures {
			if strings.Contains(strings.ToLower(line), strings.ToLower(sig)) {
				// Skróć linię jeśli za długa
				preview := line
				if len(preview) > 100 { preview = preview[:100] + "..." }
				
				sb.WriteString(fmt.Sprintf("[Line %d] %s\n", i+1, desc))
				sb.WriteString(fmt.Sprintf("   Match: \"%s\"\n", sig))
				sb.WriteString(fmt.Sprintf("   Content: %s\n\n", preview))
				threatsFound++
			}
		}
	}

	if threatsFound == 0 {
		sb.WriteString("No obvious threats found in provided logs.")
	} else {
		sb.WriteString(fmt.Sprintf("Total threats detected: %d", threatsFound))
	}

	return sb.String()
}
