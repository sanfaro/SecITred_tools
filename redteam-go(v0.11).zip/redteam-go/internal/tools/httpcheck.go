package tools

import (
	"fmt"
	"net/http"
	"strings"
	"time"
)

func CheckHeaders(url string) string {
	if !strings.HasPrefix(url, "http") {
		url = "https://" + url
	}

	client := http.Client{Timeout: 5 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return "Error connecting: " + err.Error()
	}
	defer resp.Body.Close()

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Scanning headers for: %s\n", url))
	sb.WriteString(fmt.Sprintf("Status: %s\n\n", resp.Status))

	securityHeaders := []string{
		"Strict-Transport-Security",
		"Content-Security-Policy",
		"X-Frame-Options",
		"X-Content-Type-Options",
		"Referrer-Policy",
		"Permissions-Policy",
	}

	sb.WriteString("=== SECURITY HEADERS ===\n")
	for _, h := range securityHeaders {
		val := resp.Header.Get(h)
		if val != "" {
			sb.WriteString(fmt.Sprintf("[OK] %s: %s\n", h, val))
		} else {
			sb.WriteString(fmt.Sprintf("[MISSING] %s\n", h))
		}
	}

	sb.WriteString("\n=== ALL HEADERS ===\n")
	for k, v := range resp.Header {
		sb.WriteString(fmt.Sprintf("%s: %s\n", k, strings.Join(v, ", ")))
	}

	return sb.String()
}
