package tools

import "encoding/base64"

func Base64Encode(text string) string {
	return base64.StdEncoding.EncodeToString([]byte(text))
}
