package tools

import (
	"fmt"
	"io"
	"net/http"
	"time"
)

func MACLookup(mac string) string {
	// API macvendors.co jest proste i nie wymaga klucza
	url := fmt.Sprintf("https://macvendors.co/api/%s", mac)
	
	client := http.Client{Timeout: 5 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return "Error contacting API: " + err.Error()
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "Error reading response: " + err.Error()
	}
	
	// API zwraca JSON, ale dla prostoty wyświetlimy go bezpośrednio
	return "Vendor Info:\n" + string(body)
}
