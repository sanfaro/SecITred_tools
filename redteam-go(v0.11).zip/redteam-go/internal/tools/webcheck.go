package tools

import (
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"
)

func WebCriticalScanner(url string) string {
	if !strings.HasPrefix(url, "http") {
		url = "http://" + url
	}
	url = strings.TrimRight(url, "/")

	files := []string{
		"robots.txt",
		".env",
		".git/HEAD",
		"sitemap.xml",
		".ds_store",
		"config.php",
		".htaccess",
		"id_rsa",
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Running Critical File Scan on: %s\n\n", url))

	client := http.Client{Timeout: 3 * time.Second}
	var wg sync.WaitGroup
	
	// Mutex do zapisu wyników w kolejności (opcjonalnie, tu użyjemy string buildera po locku)
	results := make(chan string, len(files))

	for _, file := range files {
		wg.Add(1)
		go func(f string) {
			defer wg.Done()
			target := url + "/" + f
			resp, err := client.Get(target)
			
			status := "ERROR"
			if err == nil {
				resp.Body.Close()
				if resp.StatusCode == 200 {
					status = "[FOUND 200] 🚨"
				} else if resp.StatusCode == 403 {
					status = "[FORBIDDEN 403] 🔒"
				} else {
					status = fmt.Sprintf("[%d]", resp.StatusCode)
				}
			}
			
			// Logujemy tylko ciekawe rzeczy (nie 404)
			if !strings.Contains(status, "404") {
				results <- fmt.Sprintf("%-15s : %s\n", "/"+f, status)
			}
		}(file)
	}

	wg.Wait()
	close(results)

	found := false
	for res := range results {
		sb.WriteString(res)
		found = true
	}

	if !found {
		sb.WriteString("No critical files found (all returned 404 or connection failed).")
	}

	return sb.String()
}
