package tools

import (
	"fmt"
	"net"
	"strings"
)

func DNSLookup(domain string) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("DNS Records for: %s\n\n", domain))

	// NS
	sb.WriteString("[NS Records]\n")
	nss, err := net.LookupNS(domain)
	if err != nil {
		sb.WriteString("  Error: " + err.Error() + "\n")
	} else {
		for _, ns := range nss {
			sb.WriteString("  " + ns.Host + "\n")
		}
	}

	// MX
	sb.WriteString("\n[MX Records]\n")
	mxs, err := net.LookupMX(domain)
	if err != nil {
		sb.WriteString("  Error: " + err.Error() + "\n")
	} else {
		for _, mx := range mxs {
			sb.WriteString(fmt.Sprintf("  %s (Pref: %d)\n", mx.Host, mx.Pref))
		}
	}

	// TXT
	sb.WriteString("\n[TXT Records]\n")
	txts, err := net.LookupTXT(domain)
	if err != nil {
		sb.WriteString("  Error: " + err.Error() + "\n")
	} else {
		for _, txt := range txts {
			sb.WriteString("  " + txt + "\n")
		}
	}

	// CNAME
	sb.WriteString("\n[CNAME]\n")
	cname, err := net.LookupCNAME(domain)
	if err == nil && cname != domain + "." {
		sb.WriteString("  " + cname + "\n")
	} else {
		sb.WriteString("  (None or same as A record)\n")
	}

	return sb.String()
}
