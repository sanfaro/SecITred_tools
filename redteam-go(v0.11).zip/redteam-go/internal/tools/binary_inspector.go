package tools

import (
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math"
	"os"
	"strings"
	"unicode"
)

// BinaryInspector analizuje zakodowany w Base64 plik binarny
// key: opcjonalny klucz API do VirusTotal (jeśli pusty, używa ENV lub pomija)
func BinaryInspector(b64Input string, apiKey string) string {
	// 1. Dekodowanie Base64
	data, err := base64.StdEncoding.DecodeString(b64Input)
	if err != nil {
		return "Error decoding Base64 input: " + err.Error()
	}

	var sb strings.Builder
	sb.WriteString("=== BINARY ANALYSIS REPORT ===\n")
	sb.WriteString(fmt.Sprintf("File Size: %d bytes (%.2f KB)\n\n", len(data), float64(len(data))/1024.0))

	// 2. Obliczanie HASHY (Nowość)
	md5Hash := hashMD5(data)
	sha1Hash := hashSHA1(data)
	sha256Hash := hashSHA256(data)

	sb.WriteString("[File Hashes]\n")
	sb.WriteString(fmt.Sprintf("MD5:    %s\n", md5Hash))
	sb.WriteString(fmt.Sprintf("SHA1:   %s\n", sha1Hash))
	sb.WriteString(fmt.Sprintf("SHA256: %s\n", sha256Hash))
	sb.WriteString("\n")

	// 3. VIRUSTOTAL CHECK (Nowość)
	// Sprawdzamy, czy mamy klucz (z parametru lub zmiennej środowiskowej)
	vtKey := apiKey
	if vtKey == "" {
		vtKey = os.Getenv("VT_API_KEY")
	}

	if vtKey != "" {
		sb.WriteString("[VirusTotal Cloud Lookup]\n")
		// Używamy istniejącej funkcji VirusTotal z pakietu tools
		// Uwaga: Funkcja VirusTotal(hash, key) musi być dostępna w tym pakiecie!
		// Ponieważ jesteśmy w package tools, możemy wywołać funkcję VirusTotal() bezpośrednio,
		// O ILE jest ona eksportowana (z dużej litery) w pliku virustotal.go (lub osint.go).
		
		vtResult := VirusTotal(sha256Hash, vtKey)
		
		// Parsujemy wynik (proste sprawdzenie czy znaleziono)
		if strings.Contains(vtResult, "Positives:") || strings.Contains(vtResult, "Malicious") {
			sb.WriteString(vtResult)
		} else if strings.Contains(vtResult, "not found") {
			sb.WriteString("✅ File hash not found in VirusTotal (Clean or New)\n")
		} else {
			sb.WriteString("⚠️  " + vtResult + "\n")
		}
		sb.WriteString(fmt.Sprintf("Link: https://www.virustotal.com/gui/file/%s\n\n", sha256Hash))
	} else {
		sb.WriteString("[VirusTotal]\nSkipped (No API Key provided). Add VT_API_KEY to .env or pass as Key parameter.\n\n")
	}

	// 4. Obliczanie Entropii
	entropy := calculateEntropy(data)
	sb.WriteString(fmt.Sprintf("Entropy: %.4f ", entropy))
	if entropy > 7.0 {
		sb.WriteString("[HIGH - Likely Packed/Encrypted] 🚨\n")
	} else {
		sb.WriteString("[Normal] ✅\n")
	}

	// 5. Detekcja typu
	magic := ""
	if len(data) > 4 {
		if string(data[:2]) == "MZ" {
			magic = "PE (Windows Executable)"
			analyzePE(data, &sb)
		} else if string(data[:4]) == "\x7fELF" {
			magic = "ELF (Linux Executable)"
			analyzeELF(data, &sb)
		} else {
			magic = "Unknown / Raw Data"
		}
	}
	sb.WriteString(fmt.Sprintf("Format: %s\n", magic))

	// 6. Stringi
	sb.WriteString("\n=== INTERESTING STRINGS (Top 20) ===\n")
	foundStrings := extractStrings(data, 100)
	for i, s := range foundStrings {
		if i >= 20 { break }
		sb.WriteString(s + "\n")
	}

	return sb.String()
}

// --- HELPERS ---

func hashMD5(data []byte) string {
	h := md5.Sum(data)
	return hex.EncodeToString(h[:])
}

func hashSHA1(data []byte) string {
	h := sha1.Sum(data)
	return hex.EncodeToString(h[:])
}

func hashSHA256(data []byte) string {
	h := sha256.Sum256(data)
	return hex.EncodeToString(h[:])
}

func calculateEntropy(data []byte) float64 {
	if len(data) == 0 { return 0 }
	freq := make(map[byte]float64)
	for _, b := range data { freq[b]++ }
	entropy := 0.0
	for _, count := range freq {
		p := count / float64(len(data))
		entropy -= p * math.Log2(p)
	}
	return entropy
}

func extractStrings(data []byte, minLen int) []string {
	var results []string
	var curr []rune
	for _, b := range data {
		r := rune(b)
		if unicode.IsPrint(r) {
			curr = append(curr, r)
		} else {
			if len(curr) >= 4 {
				s := string(curr)
				if len(s) > 300 { s = s[:300] + "..." }
				if isInteresting(s) { results = append(results, s) }
			}
			curr = curr[:0]
		}
	}
	return results
}

func isInteresting(s string) bool {
	lower := strings.ToLower(s)
	keywords := []string{"http", "https", ".com", ".exe", ".dll", "cmd", "powershell", "socket", "ip", "user", "pass", "login", "virtual", "protect"}
	if len(s) > 6 { return true }
	for _, k := range keywords { if strings.Contains(lower, k) { return true } }
	return false
}

func analyzePE(data []byte, sb *strings.Builder) {
	sb.WriteString("\n[PE Analysis]\n")
	if strings.Contains(string(data), "UPX0") { sb.WriteString("⚠️  PACKER DETECTED: UPX\n") }
	riskyFuncs := []string{"VirtualAlloc", "CreateRemoteThread", "WriteProcessMemory", "ShellExecute", "URLDownloadToFile", "InternetOpen"}
	sb.WriteString("Suspicious Imports detected:\n")
	found := false
	sData := string(data)
	for _, fn := range riskyFuncs {
		if strings.Contains(sData, fn) {
			sb.WriteString(" - " + fn + " 🔴\n")
			found = true
		}
	}
	if !found { sb.WriteString(" (None found via static scan)\n") }
}

func analyzeELF(data []byte, sb *strings.Builder) {
	sb.WriteString("\n[ELF Analysis]\n")
	if strings.Contains(string(data), "/bin/sh") { sb.WriteString("⚠️  Contains shell reference (/bin/sh)\n") }
}
