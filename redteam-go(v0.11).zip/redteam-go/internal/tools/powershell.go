package tools

import (
	"encoding/base64"
	"fmt"
	"strings"
	"unicode/utf16"
)

func PowerShellEncode(command string) string {
	// PowerShell wymaga UTF-16LE
	// Konwertujemy string na runy, potem na uint16
	u16 := utf16.Encode([]rune(command))
	
	// Konwertujemy uint16 na byte array (Little Endian)
	b := make([]byte, len(u16)*2)
	for i, v := range u16 {
		b[i*2] = byte(v)
		b[i*2+1] = byte(v >> 8)
	}

	encoded := base64.StdEncoding.EncodeToString(b)

	var sb strings.Builder
	sb.WriteString("=== PowerShell Encoded Command ===\n\n")
	sb.WriteString("Usage:\n")
	sb.WriteString(fmt.Sprintf("powershell -EncodedCommand %s\n\n", encoded))
	sb.WriteString("Raw Base64:\n")
	sb.WriteString(encoded)

	return sb.String()
}
