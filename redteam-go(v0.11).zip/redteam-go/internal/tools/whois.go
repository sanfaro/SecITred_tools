package tools

import (
	"bufio"
	"net"
	"strings"
	"time"
)

func Whois(domain string) string {
	conn, err := net.DialTimeout("tcp", "whois.iana.org:43", 5*time.Second)
	if err != nil {
		return "WHOIS error: " + err.Error()
	}
	defer conn.Close()

	conn.Write([]byte(domain + "\r\n"))

	var out strings.Builder
	scanner := bufio.NewScanner(conn)
	for scanner.Scan() {
		out.WriteString(scanner.Text() + "\n")
	}

	return out.String()
}
