package tools

func Caesar(input string, shift int) string {
	out := []rune{}
	for _, ch := range input {
		if ch >= 'a' && ch <= 'z' {
			out = append(out, 'a'+(ch-'a'+rune(shift))%26)
		} else if ch >= 'A' && ch <= 'Z' {
			out = append(out, 'A'+(ch-'A'+rune(shift))%26)
		} else {
			out = append(out, ch)
		}
	}
	return string(out)
}
