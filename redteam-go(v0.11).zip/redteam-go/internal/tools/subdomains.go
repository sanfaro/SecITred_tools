package tools

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"
)

type CrtShEntry struct {
	NameValue string `json:"name_value"`
}

func SubdomainFinder(domain string) string {
	url := fmt.Sprintf("https://crt.sh/?q=%%25.%s&output=json", domain)
	
	client := http.Client{Timeout: 10 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return "Error contacting crt.sh: " + err.Error()
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return "Error: crt.sh returned status " + resp.Status
	}

	var results []CrtShEntry
	if err := json.NewDecoder(resp.Body).Decode(&results); err != nil {
		return "Error decoding JSON: " + err.Error()
	}

	uniqueDomains := make(map[string]bool)
	for _, r := range results {
		// crt.sh czasem zwraca wiele domen w jednej linii (np. *.example.com)
		lines := strings.Split(r.NameValue, "\n")
		for _, l := range lines {
			uniqueDomains[l] = true
		}
	}

	var output strings.Builder
	output.WriteString(fmt.Sprintf("Found %d unique subdomains for %s:\n\n", len(uniqueDomains), domain))
	for d := range uniqueDomains {
		output.WriteString(d + "\n")
	}

	return output.String()
}
