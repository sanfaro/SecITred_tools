package tools

import (
	"fmt"
	"regexp"
	"strings"
)

// EmailHeaderAnalyzer analizuje surowe nagłówki emaila pod kątem phishingu
func EmailHeaderAnalyzer(rawHeaders string) string {
	var sb strings.Builder
	sb.WriteString("=== EMAIL HEADER PHISHING ANALYSIS ===\n\n")

	lines := strings.Split(rawHeaders, "\n")
	
	// Zmienne do śledzenia kluczowych pól
	var returnPath, from, replyTo, receivedIPs, spf, dkim, dmarc []string
	var suspiciousCount int

	// Regex do wyłapywania IP
	ipRegex := regexp.MustCompile(`\b(?:\d{1,3}\.){3}\d{1,3}\b`)

	for _, line := range lines {
		line = strings.TrimSpace(line)
		lower := strings.ToLower(line)

		// SPF
		if strings.Contains(lower, "received-spf:") {
			spf = append(spf, line)
			if strings.Contains(lower, "fail") || strings.Contains(lower, "softfail") {
				suspiciousCount++
			}
		}

		// DKIM
		if strings.Contains(lower, "dkim-signature:") || strings.Contains(lower, "authentication-results:") {
			dkim = append(dkim, line)
			if strings.Contains(lower, "dkim=fail") {
				suspiciousCount++
			}
		}

		// DMARC
		if strings.Contains(lower, "dmarc=") {
			dmarc = append(dmarc, line)
			if strings.Contains(lower, "dmarc=fail") {
				suspiciousCount++
			}
		}

		// Return-Path
		if strings.HasPrefix(lower, "return-path:") {
			returnPath = append(returnPath, strings.TrimPrefix(line, "Return-Path:"))
		}

		// From
		if strings.HasPrefix(lower, "from:") {
			from = append(from, strings.TrimPrefix(line, "From:"))
		}

		// Reply-To
		if strings.HasPrefix(lower, "reply-to:") {
			replyTo = append(replyTo, strings.TrimPrefix(line, "Reply-To:"))
		}

		// Received (IP Extraction)
		if strings.HasPrefix(lower, "received:") {
			ips := ipRegex.FindAllString(line, -1)
			receivedIPs = append(receivedIPs, ips...)
		}
	}

	// === ANALIZA ===
	
	// 1. SPF/DKIM/DMARC
	sb.WriteString("[Authentication Status]\n")
	if len(spf) > 0 {
		sb.WriteString("SPF: " + strings.Join(spf, ", ") + "\n")
	} else {
		sb.WriteString("SPF: NOT FOUND (Suspicious)\n")
		suspiciousCount++
	}

	if len(dkim) > 0 {
		sb.WriteString("DKIM: " + strings.Join(dkim, ", ") + "\n")
	} else {
		sb.WriteString("DKIM: NOT FOUND\n")
	}

	if len(dmarc) > 0 {
		sb.WriteString("DMARC: " + strings.Join(dmarc, ", ") + "\n")
	} else {
		sb.WriteString("DMARC: NOT FOUND\n")
	}

	// 2. From vs Reply-To mismatch
	sb.WriteString("\n[Sender Analysis]\n")
	if len(from) > 0 {
		sb.WriteString("From: " + from[0] + "\n")
	}
	if len(replyTo) > 0 {
		sb.WriteString("Reply-To: " + replyTo[0] + "\n")
		if len(from) > 0 && !strings.Contains(strings.ToLower(from[0]), strings.ToLower(replyTo[0])) {
			sb.WriteString("⚠️  WARNING: Reply-To differs from From (common phishing tactic)\n")
			suspiciousCount++
		}
	}
	if len(returnPath) > 0 {
		sb.WriteString("Return-Path: " + returnPath[0] + "\n")
	}

	// 3. IP Trace
	sb.WriteString("\n[IP Chain (Received Headers)]\n")
	if len(receivedIPs) > 0 {
		for _, ip := range receivedIPs {
			sb.WriteString("  " + ip + "\n")
		}
	} else {
		sb.WriteString("  No IPs found\n")
	}

	// 4. Risk Score
	sb.WriteString("\n=== PHISHING RISK SCORE ===\n")
	if suspiciousCount == 0 {
		sb.WriteString("✅ LOW RISK (0 red flags)\n")
	} else if suspiciousCount <= 2 {
		sb.WriteString(fmt.Sprintf("⚠️  MEDIUM RISK (%d red flags)\n", suspiciousCount))
	} else {
		sb.WriteString(fmt.Sprintf("🚨 HIGH RISK (%d red flags) - Likely Phishing!\n", suspiciousCount))
	}

	return sb.String()
}
