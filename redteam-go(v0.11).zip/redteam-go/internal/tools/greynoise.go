package tools

import (
	"io"
	"net/http"
)

func GreyNoise(input, apiKey string) string {
	if apiKey == "" {
		return "ERROR: GreyNoise API key required"
	}

	req, _ := http.NewRequest(
		"GET",
		"https://api.greynoise.io/v3/community/"+input,
		nil,
	)

	req.Header.Set("key", apiKey)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err.Error()
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	return string(body)
}
