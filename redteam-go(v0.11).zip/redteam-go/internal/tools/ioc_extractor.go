package tools

import (
	"regexp"
	"strings"
)

func IOCExtractor(text string, mode string) string {
	// mode: "extract" (wyciągnij i napraw), "defang" (zepsuj linki do raportu)
	
	if mode == "defang" {
		text = strings.ReplaceAll(text, ".", "[.]")
		text = strings.ReplaceAll(text, "http", "hxxp")
		return "=== DEFANGED OUTPUT ===\n" + text
	}

	// Refang (naprawianie hxxp -> http, [.] -> .)
	text = strings.ReplaceAll(text, "[.]", ".")
	text = strings.ReplaceAll(text, "(.)", ".")
	text = strings.ReplaceAll(text, "hxxp", "http")

	// Regexy
	ipRegex := regexp.MustCompile(`\b(?:\d{1,3}\.){3}\d{1,3}\b`)
	domainRegex := regexp.MustCompile(`([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}`)
	emailRegex := regexp.MustCompile(`[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}`)

	ips := ipRegex.FindAllString(text, -1)
	domains := domainRegex.FindAllString(text, -1)
	emails := emailRegex.FindAllString(text, -1)

	// Usuwanie duplikatów (prosta mapa)
	unique := make(map[string]bool)
	var sb strings.Builder

	sb.WriteString("=== EXTRACTED IOCs ===\n\n")

	sb.WriteString("[IP Addresses]\n")
	for _, ip := range ips {
		if !unique[ip] {
			sb.WriteString(ip + "\n")
			unique[ip] = true
		}
	}

	sb.WriteString("\n[Emails]\n")
	for _, mail := range emails {
		if !unique[mail] {
			sb.WriteString(mail + "\n")
			unique[mail] = true
		}
	}

	sb.WriteString("\n[Domains/URLs]\n")
	for _, dom := range domains {
		// Filtrowanie IP które wpadły w regex domen
		if !unique[dom] && !strings.Contains(dom, "@") { 
			// Sprawdź czy to nie jest IP
			if ipRegex.MatchString(dom) { continue }
			sb.WriteString(dom + "\n")
			unique[dom] = true
		}
	}

	return sb.String()
}
