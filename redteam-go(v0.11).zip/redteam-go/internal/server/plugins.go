package server

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// Definicja Pluginu w pliku JSON
type PluginDefinition struct {
	Name        string   `json:"name"`
	Category    string   `json:"category"`
	Description string   `json:"description"`
	Command     string   `json:"command"`
	Args        []string `json:"args"`
	InputLabel  string   `json:"inputLabel"`
	KeyLabel    string   `json:"keyLabel"`
	NeedsKey    bool     `json:"needsKey"`
}

// Globalny rejestr załadowanych pluginów
var PluginRegistry = make(map[string]PluginDefinition)

// Funkcja ładująca pluginy przy starcie serwera
func LoadPlugins() {
	pluginDir := "plugins"
	
	// Upewnij się, że folder istnieje
	if _, err := os.Stat(pluginDir); os.IsNotExist(err) {
		os.Mkdir(pluginDir, 0755)
		logEvent("INFO", "Created plugins directory")
		return
	}

	files, err := os.ReadDir(pluginDir)
	if err != nil {
		logEvent("ERROR", "Failed to read plugins dir: "+err.Error())
		return
	}

	count := 0
	for _, file := range files {
		if strings.HasSuffix(file.Name(), ".json") {
			path := filepath.Join(pluginDir, file.Name())
			content, err := os.ReadFile(path)
			if err != nil {
				logEvent("WARN", "Skipping plugin "+file.Name()+": "+err.Error())
				continue
			}

			var plug PluginDefinition
			if err := json.Unmarshal(content, &plug); err != nil {
				logEvent("WARN", "Invalid JSON in "+file.Name()+": "+err.Error())
				continue
			}

			// Rejestracja pluginu
			PluginRegistry[plug.Name] = plug
			
			// Dodanie do globalnego toolRegistry (żeby frontend go widział)
			toolRegistry = append(toolRegistry, Tool{
				Name:        plug.Name,
				Category:    plug.Category,
				NeedsKey:    plug.NeedsKey,
				Description: plug.Description + " (External Plugin)",
				InputLabel:  plug.InputLabel,
				KeyLabel:    plug.KeyLabel,
			})
			
			count++
		}
	}
	logEvent("INFO", fmt.Sprintf("Loaded %d external plugins", count))
}

// Funkcja wykonująca plugin
func ExecutePlugin(name string, input string, key string) (string, error) {
	plug, exists := PluginRegistry[name]
	if !exists {
		return "", fmt.Errorf("plugin not found")
	}

	// Podmiana placeholderów w argumentach
	var finalArgs []string
	for _, arg := range plug.Args {
		arg = strings.ReplaceAll(arg, "{{input}}", input)
		arg = strings.ReplaceAll(arg, "{{key}}", key)
		finalArgs = append(finalArgs, arg)
	}

	// Uruchomienie komendy
	cmd := exec.Command(plug.Command, finalArgs...)
	
	// Zabezpieczenie przed wiszącymi procesami (timeout 30s)
	done := make(chan error, 1)
	var output []byte
	
	go func() {
		var err error
		output, err = cmd.CombinedOutput()
		done <- err
	}()

	select {
	case <-time.After(30 * time.Second):
		if cmd.Process != nil {
			cmd.Process.Kill()
		}
		return string(output) + "\n[TIMEOUT]", fmt.Errorf("plugin execution timed out")
	case err := <-done:
		if err != nil {
			return string(output) + "\n[EXIT ERROR: " + err.Error() + "]", nil
		}
		return string(output), nil
	}
}
