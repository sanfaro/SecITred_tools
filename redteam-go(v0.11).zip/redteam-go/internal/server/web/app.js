document.addEventListener('DOMContentLoaded', () => {
    let currentTool = null;

    // --- ELEMENTY DOM ---
    const toolsListEl = document.getElementById('toolsList');
    const runBtn = document.getElementById('runBtn');
    const inputText = document.getElementById('inputText');
    const outputText = document.getElementById('outputText');
    const paramKey = document.getElementById('paramKey');
    const currentToolLabel = document.getElementById('currentToolName');
    const externalLink = document.getElementById('externalLink');
    const searchInput = document.getElementById('searchTools');
    const inputLabel = document.getElementById('inputLabel');
    const toolDesc = document.getElementById('toolDescription');
    const logConsole = document.getElementById('logConsole');
    
    // Upload Plików (NOWOŚĆ)
    const fileInput = document.getElementById('fileInput');
    const uploadBtn = document.getElementById('uploadBtn');

    // Tool Info Tab
    const infoToolName = document.getElementById('infoToolName');
    const infoDescription = document.getElementById('infoDescription');
    const infoInputFormat = document.getElementById('infoInputFormat');
    const infoKeyFormat = document.getElementById('infoKeyFormat');
    const infoExample = document.getElementById('infoExample');

    // Pipeline Elements
    const pipelineToolSelect = document.getElementById('pipelineToolSelect');
    const pipelineKeyInput = document.getElementById('pipelineKeyInput');
    const pipelineAddStepBtn = document.getElementById('pipelineAddStepBtn');
    const pipelineRunBtn = document.getElementById('pipelineRunBtn');
    const pipelineClearBtn = document.getElementById('pipelineClearBtn');
    const pipelineStepsEl = document.getElementById('pipelineSteps');
    const pipelineOutput = document.getElementById('pipelineOutput');
    const pipelineUseFinalBtn = document.getElementById('pipelineUseFinalBtn');
    const pipelineExternalLink = document.getElementById('pipelineExternalLink');

    // --- ZMIENNE STANU ---
    let toolsCache = [];
    let pipelineSteps = [];

    // --- 1. OBSŁUGA ZAKŁADEK ---
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
        });
    });

    // --- 2. POBIERANIE NARZĘDZI ---
    fetch('/api/tools')
        .then(r => r.json())
        .then(tools => {
            toolsCache = tools || [];
            renderTools(toolsCache);
            renderPipelineToolOptions(toolsCache);
        })
        .catch(err => console.error("API Error:", err));

    function renderTools(tools) {
        toolsListEl.innerHTML = '';
        const categories = {};
        
        tools.forEach(t => {
            if (!categories[t.category]) categories[t.category] = [];
            categories[t.category].push(t);
        });

        for (const [catName, catTools] of Object.entries(categories)) {
            const header = document.createElement('div');
            header.className = 'category-header';
            header.innerText = catName.toUpperCase();
            toolsListEl.appendChild(header);

            catTools.forEach(tool => {
                const btn = document.createElement('button');
                btn.className = 'tool-btn';
                btn.innerText = tool.name;
                btn.onclick = () => selectTool(tool, btn);
                toolsListEl.appendChild(btn);
            });
        }
    }

    // --- 3. WYBÓR NARZĘDZIA ---
    function selectTool(tool, btnElement) {
        currentTool = tool;

        // Workspace Updates
        currentToolLabel.innerText = tool.name.toUpperCase();
        inputLabel.innerText = (tool.inputLabel || "INPUT").toUpperCase();
        inputText.placeholder = `Enter ${tool.inputLabel || "text"} here...`;

        // Tooltip description
        toolDesc.innerText = tool.description || "No description.";
        toolDesc.classList.remove('hidden');

        // Info Tab Updates
        infoToolName.innerText = tool.name.toUpperCase();
        infoDescription.innerText = tool.description || "No description available.";
        infoInputFormat.innerText = tool.inputLabel || "Any text";
        infoKeyFormat.innerText = tool.keyLabel || (tool.needsKey ? "Required" : "Not required");
        infoExample.innerText = getToolExample(tool.name);

        // Key Input Logic
        if (tool.needsKey || tool.keyLabel) {
            paramKey.classList.remove('hidden');
            paramKey.placeholder = tool.keyLabel || "Key";
            paramKey.style.borderColor = tool.needsKey ? "var(--accent)" : "#333";
            if (tool.name === 'revshell') paramKey.value = "4444";
            else paramKey.value = "";
        } else {
            paramKey.classList.add('hidden');
        }

        // Highlight Button
        document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
        if(btnElement) btnElement.classList.add('active');
    }

    function getToolExample(toolName) {
        const examples = {
            'base64': 'Input: Hello World\nOutput: SGVsbG8gV29ybGQ=',
            'xor': 'Input: Secret\nKey: 123\nOutput: Encrypted Bytes',
            'binanalyze': 'Input: [Base64 Encoded File]\nOutput: PE/ELF Analysis, Strings, Entropy',
            'ioc': 'Input: 192[.]168.1.1\nKey: defang\nOutput: 192[.]168[.]1[.]1',
            'uaparser': 'Input: Mozilla/5.0...\nOutput: Windows 10, Chrome, Risk: Low',
            'loganalyze': 'Input: 10.0.0.1 GET /index.php?id=1 UNION SELECT...\nOutput: [Line 1] SQL Injection',
            'gtfobins': 'Input: vim\nOutput: :set shell=/bin/sh\n:shell',
        };
        return examples[toolName] || 'No example available.';
    }

    // --- 4. URUCHOMIENIE (RUN) ---
    async function runTool() {
        if (!currentTool) return;
        
        runBtn.innerText = "...";
        outputText.value = "Processing...";
        externalLink.classList.add('hidden');

        try {
            const res = await fetch('/api/run', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    tool: currentTool.name,
                    text: inputText.value,
                    key: paramKey.value
                })
            });

            const data = await res.json();
            
            if (data.error) {
                outputText.value = "ERROR: " + data.error;
            } else {
                outputText.value = data.result;
                if (data.external_url) {
                    externalLink.href = data.external_url;
                    externalLink.classList.remove('hidden');
                }
            }
        } catch (e) {
            outputText.value = "Network Error: " + e;
        } finally {
            runBtn.innerText = "RUN ▷";
        }
    }

    // --- 5. PIPELINE LOGIC (Brakowało tego w twoim kodzie) ---
    function renderPipelineToolOptions(tools) {
        pipelineToolSelect.innerHTML = '';
        const sorted = [...tools].sort((a,b) => a.name.localeCompare(b.name));
        for (const t of sorted) {
            const opt = document.createElement('option');
            opt.value = t.name;
            opt.textContent = `${t.name} (${t.category})`;
            pipelineToolSelect.appendChild(opt);
        }
    }

    function renderPipelineSteps() {
        pipelineStepsEl.innerHTML = '';
        if (pipelineSteps.length === 0) {
            pipelineStepsEl.innerHTML = `<div style="color:#888;">No steps. Add tools to build your pipeline.</div>`;
            return;
        }

        pipelineSteps.forEach((step, idx) => {
            const row = document.createElement('div');
            row.className = 'pipeline-step';
            row.innerHTML = `
                <div class="pipeline-step-left">
                    <div class="pipeline-step-title"><span class="pipeline-badge">#${idx+1}</span> ${step.tool}</div>
                    <div class="pipeline-step-meta">Key: ${step.key ? step.key : '(empty)'}</div>
                </div>
                <div class="pipeline-step-actions">
                    <button class="secondary-btn" data-action="remove" data-idx="${idx}">Remove</button>
                </div>
            `;
            pipelineStepsEl.appendChild(row);
        });

        pipelineStepsEl.querySelectorAll('button[data-action="remove"]').forEach(btn => {
            btn.addEventListener('click', () => {
                pipelineSteps.splice(parseInt(btn.dataset.idx), 1);
                renderPipelineSteps();
            });
        });
    }

    async function runPipeline() {
        if (pipelineSteps.length === 0) { alert("Pipeline is empty."); return; }
        const initialInput = inputText.value || "";
        if (!initialInput) { alert("Workspace input is empty."); return; }

        pipelineRunBtn.disabled = true;
        pipelineOutput.value = "Running pipeline...\n";
        
        let current = initialInput;

        for (let i = 0; i < pipelineSteps.length; i++) {
            const step = pipelineSteps[i];
            pipelineOutput.value += `\n[Step ${i+1}] ${step.tool}...\n`;

            try {
                const res = await fetch('/api/run', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tool: step.tool, text: current, key: step.key || "" })
                });
                const data = await res.json();
                
                if (data.error) {
                    pipelineOutput.value += `ERROR: ${data.error}\nSTOPPED.\n`;
                    break;
                }
                current = data.result;
                pipelineOutput.value += "OK\n";
            } catch (e) {
                pipelineOutput.value += `NETWORK ERROR: ${e}\n`;
                break;
            }
        }
        pipelineOutput.value += `\n--- FINAL OUTPUT ---\n${current}`;
        pipelineRunBtn.disabled = false;
    }

    // --- 6. EVENT LISTENERS ---

    // === OBSŁUGA PLIKÓW (TWOJA PROŚBA) ===
    uploadBtn.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(e) {
            // e.target.result to "data:application/octet-stream;base64,AAAA..."
            const base64Raw = e.target.result.split(',')[1];
            inputText.value = base64Raw;
            
            
            
            // info for user
            
            logConsole.innerHTML += `<div style="color: #00d084;">> Loaded file: ${file.name} (${file.size} bytes)</div>`;
            logConsole.scrollTop = logConsole.scrollHeight;
        };
        reader.readAsDataURL(file);
    });
    // ======================================

    // Run & Search
    runBtn.addEventListener('click', runTool);
    inputText.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'Enter') runTool();
    });
    searchInput.addEventListener('input', (e) => {
        const val = e.target.value.toLowerCase();
        document.querySelectorAll('.tool-btn').forEach(btn => {
            btn.style.display = btn.innerText.toLowerCase().includes(val) ? 'block' : 'none';
        });
    });

    // Copy & Clear
    document.getElementById('copyBtn').addEventListener('click', () => {
        outputText.select();
        document.execCommand('copy');
    });
    document.getElementById('clearLogs').addEventListener('click', () => {
        logConsole.innerHTML = '<div style="color: #666;">> Console cleared locally.</div>';
    });

    // Chain (Output -> Input)
    document.getElementById('chainBtn').addEventListener('click', () => {
        const out = outputText.value;
        if (!out || out.startsWith("ERROR")) { alert("Output empty or error."); return; }
        inputText.value = out;
        outputText.value = "";
        document.querySelector('[data-tab="workspace"]').click(); 
    });

    // Pipeline Events
    pipelineAddStepBtn.addEventListener('click', () => {
        const toolName = pipelineToolSelect.value;
        if (!toolName) return;
        pipelineSteps.push({ tool: toolName, key: pipelineKeyInput.value || "" });
        pipelineKeyInput.value = "";
        renderPipelineSteps();
    });
    pipelineRunBtn.addEventListener('click', runPipeline);
    pipelineClearBtn.addEventListener('click', () => {
        pipelineSteps = [];
        pipelineOutput.value = "";
        renderPipelineSteps();
    });
    pipelineUseFinalBtn.addEventListener('click', () => {
        const txt = pipelineOutput.value;
        const marker = "\n--- FINAL OUTPUT ---\n";
        const idx = txt.lastIndexOf(marker);
        if (idx >= 0) inputText.value = txt.substring(idx + marker.length);
        document.querySelector('[data-tab="workspace"]').click();
    });

    // Logs Polling (Live Console)
    setInterval(() => {
        fetch('/api/logs').then(r => r.json()).then(logs => {
            if (!logs || logs.length === 0) return;
            const logHtml = logs.map(line => {
                let color = "#00ff00";
                if (line.includes("ERROR")) color = "#ff4444";
                if (line.includes("WARN")) color = "#ffbb33";
                return `<div style="color:${color}">${line}</div>`;
            }).join('');
            logConsole.innerHTML = logHtml;
            logConsole.scrollTop = logConsole.scrollHeight;
        }).catch(()=>{});
    }, 2000);
});

