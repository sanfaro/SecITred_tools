package server

import (
	"embed"
	"encoding/json"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"

	"redteam/internal/tools"
)

//go:embed web/*
var webFS embed.FS

// ------------------ STRUKTURY DANYCH ------------------

type Request struct {
	Tool string `json:"tool"`
	Text string `json:"text"`
	Key  string `json:"key"`
}

type ToolResponse struct {
	Result      string `json:"result"`
	ExternalURL string `json:"external_url,omitempty"`
	Error       string `json:"error,omitempty"`
}

type HistoryEntry struct {
	Time   string `json:"time"`
	Tool   string `json:"tool"`
	Input  string `json:"input"`
	Output string `json:"output"`
}

// Globalny stan aplikacji
var (
	history []HistoryEntry
	appLogs []string
	mu      sync.Mutex
	logMu   sync.Mutex
)

// Helper: Loguje zdarzenie
func logEvent(level, msg string) {
	timestamp := time.Now().Format("15:04:05")
	entry := fmt.Sprintf("[%s] %s: %s", timestamp, level, msg)
	log.Println(entry)

	logMu.Lock()
	defer logMu.Unlock()
	if len(appLogs) > 50 {
		appLogs = appLogs[1:]
	}
	appLogs = append(appLogs, entry)
}

// Helper do pobierania klucza
func getAPIKey(envVarName string, userInput string) string {
	if key := os.Getenv(envVarName); key != "" {
		return key
	}
	return userInput
}

// ------------------ REJESTR NARZĘDZI (LOGIKA) ------------------

type ToolHandler func(text string, userKey string) (string, string, error)

var ToolHandlers = map[string]ToolHandler{
	// --- KRYPTOGRAFIA & MISC ---
	"base64": func(text, key string) (string, string, error) {
		return tools.Base64Encode(text), "", nil
	},
	"sha256": func(text, key string) (string, string, error) {
		return tools.SHA256(text), "", nil
	},
	"xor": func(text, key string) (string, string, error) {
		return tools.XOR(text, key), "", nil
	},
	"caesar": func(text, key string) (string, string, error) {
		shift, _ := strconv.Atoi(key)
		return tools.Caesar(text, shift), "", nil
	},
	"rot13": func(text, key string) (string, string, error) {
		return tools.ROT13(text), "", nil
	},
	"urlencode": func(text, key string) (string, string, error) {
		return tools.URLEncode(text), "", nil
	},
	"echo": func(text, key string) (string, string, error) {
		return tools.Echo(text), "", nil
	},
	"jwt": func(text, key string) (string, string, error) {
		return tools.JWTDecode(text), "https://jwt.io", nil
	},
	"mac": func(text, key string) (string, string, error) {
		return tools.MACLookup(text), "https://macvendors.co/results/" + text, nil
	},
	"hashid": func(text, key string) (string, string, error) {
		return tools.HashIdentifier(text), "", nil
	},

	// --- RECON (RED TEAM) ---
	"subdomains": func(text, key string) (string, string, error) {
		return tools.SubdomainFinder(text), "https://crt.sh/?q=" + text, nil
	},
	"portscan": func(text, key string) (string, string, error) {
		return tools.PortScan(text), "", nil
	},
	"revshell": func(text, key string) (string, string, error) {
		if key == "" { key = "4444" }
		return tools.RevShellGen(text, key), "", nil
	},
	"dns": func(text, key string) (string, string, error) {
		return tools.DNSLookup(text), "https://mxtoolbox.com/SuperTool.aspx?action=mx%3a" + text, nil
	},

	// --- BLUE TEAM ---
	"httpheaders": func(text, key string) (string, string, error) {
		return tools.CheckHeaders(text), "", nil
	},
	"whois": func(text, key string) (string, string, error) {
		return tools.Whois(text), "", nil
	},
	"emailheaders": func(text, key string) (string, string, error) {
		return tools.EmailHeaderAnalyzer(text), "", nil
	},
	"ioc": func(text, key string) (string, string, error) {
		// key = "defang" lub puste (extract)
		return tools.IOCExtractor(text, key), "", nil
	},
	"uaparser": func(text, key string) (string, string, error) {
		return tools.UserAgentParser(text), "", nil
	},
	"loganalyze": func(text, key string) (string, string, error) {
		return tools.LogAnalyzer(text), "", nil
	},
	
	
			// SANDBOX
	"binanalyze": func(text, key string) (string, string, error) {
		// text = plik Base64
		// key  = opcjonalny klucz VT (lub pusty)
		return tools.BinaryInspector(text, key), "", nil
	},




	// --- OSINT (Zewnętrzne API - Graceful Degradation) ---
	"shodan": func(text, key string) (string, string, error) {
		finalKey := getAPIKey("SHODAN_API_KEY", key)
		link := "https://www.shodan.io/host/" + text
		if finalKey == "" {
			return "INFO: No API Key provided. Click 'Open External' to view on Shodan website.", link, nil
		}
		return tools.Shodan(text, finalKey), link, nil
	},

	"virustotal": func(text, key string) (string, string, error) {
		finalKey := getAPIKey("VT_API_KEY", key)
		link := "https://www.virustotal.com/gui/search/" + text
		if finalKey == "" {
			return "INFO: No API Key provided. Click 'Open External' to check manually on VirusTotal.", link, nil
		}
		return tools.VirusTotal(text, finalKey), link, nil
	},

	"abuseipdb": func(text, key string) (string, string, error) {
		finalKey := getAPIKey("ABUSEIPDB_API_KEY", key)
		link := "https://www.abuseipdb.com/check/" + text
		if finalKey == "" {
			return "INFO: No API Key provided. Click 'Open External' to check on AbuseIPDB website.", link, nil
		}
		return tools.AbuseIPDB(text, finalKey), link, nil
	},

	"securitytrails": func(text, key string) (string, string, error) {
		finalKey := getAPIKey("SECURITYTRAILS_API_KEY", key)
		link := "https://securitytrails.com/domain/" + text
		if finalKey == "" {
			return "INFO: No API Key provided. Click 'Open External' to view on SecurityTrails.", link, nil
		}
		return tools.SecurityTrails(text, finalKey), link, nil
	},

	// --- OSINT (Bez klucza) ---
	"greynoise": func(text, key string) (string, string, error) {
		return tools.GreyNoise(text, key), "https://viz.greynoise.io/ip/" + text, nil
	},
	"otx": func(text, key string) (string, string, error) {
		return tools.OTX(text, key), "https://otx.alienvault.com/indicator/ip/" + text, nil
	},
	"urlscan": func(text, key string) (string, string, error) {
		return tools.URLScan(text, key), "", nil
	},
}

// ------------------ SERVER BOOTSTRAP ------------------

func Start() {
	logEvent("INFO", "Starting SecITRed server...")

	// Wczytanie pluginów przy starcie
	LoadPlugins()

	mux := http.NewServeMux()

	// 1. Frontend
	sub, err := fs.Sub(webFS, "web")
	if err != nil {
		log.Fatal("FS SUB ERROR:", err)
	}
	mux.Handle("/", http.FileServer(http.FS(sub)))

	// 2. API
	mux.HandleFunc("/api/tools", enableCORS(handleTools))
	mux.HandleFunc("/api/run", enableCORS(handleRun))
	mux.HandleFunc("/api/logs", enableCORS(handleLogs))

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	logEvent("INFO", fmt.Sprintf("Listening on :%s", port))
	if err := http.ListenAndServe(":"+port, mux); err != nil {
		log.Fatal(err)
	}
}

// ------------------ HANDLERY HTTP ------------------

func handleRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req Request
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		logEvent("ERROR", "Invalid JSON request received")
		http.Error(w, "Invalid JSON body", http.StatusBadRequest)
		return
	}

	shortInput := req.Text
	if len(shortInput) > 20 {
		shortInput = shortInput[:20] + "..."
	}
	logEvent("INFO", fmt.Sprintf("Running tool '%s' on input: %s", req.Tool, shortInput))

	// 1. Sprawdź NATYWNE narzędzia
	if handler, exists := ToolHandlers[req.Tool]; exists {
		start := time.Now()
		result, externalURL, err := handler(req.Text, req.Key)
		duration := time.Since(start)

		if err != nil {
			logEvent("ERROR", fmt.Sprintf("Tool '%s' failed: %v", req.Tool, err))
			jsonError(w, err.Error(), http.StatusInternalServerError)
			return
		}
		logEvent("SUCCESS", fmt.Sprintf("Tool '%s' finished in %v", req.Tool, duration))

		go saveToHistory(req.Tool, req.Text, result)
		
		resp := ToolResponse{
			Result:      result,
			ExternalURL: externalURL,
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(resp)
		return
	}

	// 2. Sprawdź PLUGINY (PluginRegistry jest w plugins.go)
	if _, isPlugin := PluginRegistry[req.Tool]; isPlugin {
		logEvent("INFO", fmt.Sprintf("Executing external plugin '%s'...", req.Tool))
		
		start := time.Now()
		output, err := ExecutePlugin(req.Tool, req.Text, req.Key)
		duration := time.Since(start)

		if err != nil {
			logEvent("ERROR", fmt.Sprintf("Plugin '%s' error: %v", req.Tool, err))
		} else {
			logEvent("SUCCESS", fmt.Sprintf("Plugin '%s' finished in %v", req.Tool, duration))
		}

		go saveToHistory(req.Tool, req.Text, output)
		
		resp := ToolResponse{Result: output}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(resp)
		return
	}

	// 3. Jeśli nic nie znaleziono
	logEvent("WARN", "Unknown tool requested: "+req.Tool)
	jsonError(w, "Unknown tool: "+req.Tool, http.StatusBadRequest)
}

func handleTools(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(toolRegistry)
}

func handleLogs(w http.ResponseWriter, r *http.Request) {
	logMu.Lock()
	defer logMu.Unlock()
	
	w.Header().Set("Content-Type", "application/json")
	logsCopy := make([]string, len(appLogs))
	copy(logsCopy, appLogs)
	json.NewEncoder(w).Encode(logsCopy)
}

// ------------------ HELPERY ------------------

func saveToHistory(tool, input, output string) {
	mu.Lock()
	defer mu.Unlock()
	
	if len(history) > 100 {
		history = history[1:]
	}

	history = append(history, HistoryEntry{
		Time:   time.Now().Format(time.RFC3339),
		Tool:   tool,
		Input:  input,
		Output: output,
	})
}

func jsonError(w http.ResponseWriter, message string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": message})
}

func enableCORS(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}
		next(w, r)
	}
}
