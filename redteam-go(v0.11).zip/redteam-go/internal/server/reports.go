package server

import (
	"net/http"
	"os"
)

func generateHTML(history []HistoryEntry) string {
	html := "<html><body><h1>Pentest Report</h1>"
	for _, h := range history {
		html += "<h3>" + h.Tool + "</h3>"
		html += "<pre>" + h.Output + "</pre>"
	}
	html += "</body></html>"
	return html
}

func handleReport(w http.ResponseWriter, r *http.Request) {
	html := generateHTML(history)

	os.MkdirAll("internal/data/reports", 0755)
	path := "internal/data/reports/report.html"
	os.WriteFile(path, []byte(html), 0644)

	w.Header().Set("Content-Type", "text/html")
	w.Write([]byte(html))
}
